﻿

public class patch_FriendTracker
{
    public static void Patch()
    {
        // On.FriendTracker.RunSpeed += BP_RunSpeed;
    }


	public static float BP_RunSpeed(On.FriendTracker.orig_RunSpeed orig, FriendTracker self)
	{
		//return 1f;
        if (self.AI.creature.pos.room == self.friendDest.room && patch_Player.IsStuck(self.friend as Player))
		{
			return 0.5f;
		}
		//else if ((self.AI.creature.realizedCreature as Lizard).AI.behavior == LizardAI.Behavior.FollowFriend)

		else
			return orig.Invoke(self);
	}


	//public static void BP_Update(On.FriendTracker.orig_Update orig, FriendTracker self)
	//{
	//	orig.Invoke(self);
	//}


}