﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using Menu.Remix;
using MoreSlugcats;
using UnityEngine;

namespace Expedition
{
	
	public class CycleFoodChallenge : Challenge
	{
		
		public override void UpdateDescription()
		{
			int value = this.completed ? this.target : this.score;
			this.description = ChallengeTools.IGT.Translate("Hibernate with <score_target> bonus food pips this cycle [<current_score>]").Replace("<score_target>", ValueConverter.ConvertToString<int>(this.target)).Replace("<current_score>", ValueConverter.ConvertToString<int>(value));
			base.UpdateDescription();
		}

		public override bool Duplicable(Challenge challenge)
		{
			return !(challenge is CycleFoodChallenge);
		}

		public override void Reset()
		{
			this.score = 0;
			base.Reset();
		}

		public override string ChallengeName()
		{
			return ChallengeTools.IGT.Translate("Cycle Food Score");
		}

		public override Challenge Generate()
		{
			int num = (int)Mathf.Lerp(5f, 15f, ExpeditionData.challengeDifficulty);
			if (ExpeditionGame.activeUnlocks.Contains("bur-rotund"))
				num -= 3;

			if (ModManager.MSC && (ExpeditionData.slugcatPlayer == MoreSlugcatsEnums.SlugcatStatsName.Spear || ExpeditionData.slugcatPlayer == MoreSlugcatsEnums.SlugcatStatsName.Saint))
				num /= 2;

			return new CycleFoodChallenge
			{
				target = num
			};
		}

		public override int Points()
		{
			float num = 1f;
			float baseTarg = this.target;
			if (ExpeditionGame.activeUnlocks.Contains("bur-rotund"))
				baseTarg += 3;
			return (int)((float)(baseTarg * 3) * num) * (int)(this.hidden ? 2f : 1f);
		}

		
		public override void Update()
		{
			base.Update();

			if (this.score != BellyPlus.bonusFood)
			{
				this.score = BellyPlus.bonusFood;
				this.UpdateDescription();
			}

			if (this.game.cameras[0].room.shelterDoor != null && this.game.cameras[0].room.shelterDoor.IsClosing)
			{
                if (this.score >= this.target)
					this.CompleteChallenge();
				return;
			}
		}

		// Token: 0x0600363F RID: 13887 RVA: 0x003D3AA4 File Offset: 0x003D1CA4
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"CycleFoodChallenge",
				"~",
				ValueConverter.ConvertToString<int>(this.target),
				"><",
				this.completed ? "1" : "0",
				"><",
				this.hidden ? "1" : "0",
				"><",
				this.revealed ? "1" : "0"
			});
		}

		// Token: 0x06003640 RID: 13888 RVA: 0x003D3B38 File Offset: 0x003D1D38
		public override void FromString(string args)
		{
			try
			{
				string[] array = Regex.Split(args, "><");
				this.target = int.Parse(array[0], NumberStyles.Any, CultureInfo.InvariantCulture);
				this.completed = (array[1] == "1");
				this.hidden = (array[2] == "1");
				this.revealed = (array[3] == "1");
				if (!this.completed)
				{
					this.score = 0;
				}
				this.score = 0;
				this.UpdateDescription();
			}
			catch (Exception ex)
			{
				ExpLog.Log("ERROR: CycleFoodChallenge FromString() encountered an error: " + ex.Message);
			}
		}

		// Token: 0x04003C68 RID: 15464
		public int target;

		// Token: 0x04003C69 RID: 15465
		public int score;

		// Token: 0x04003C6A RID: 15466
		public int increase;

		// Token: 0x04003C6B RID: 15467
		public int[] killScores;
	}
}
