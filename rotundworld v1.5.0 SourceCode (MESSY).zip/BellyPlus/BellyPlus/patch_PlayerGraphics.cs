﻿using System;
using RWCustom;
using UnityEngine;
using MonoMod.RuntimeDetour;

public class patch_PlayerGraphics
{
    //static readonly int bl = 12;
	//CURRENTLY THE ONLY PART OF THESE GRAPHICS THAT ARE GIVEN HARD SET VALUES ARE THE FACE SPRITE.SCALEY

    public struct BPgraph
    {
        public bool breathIn;
        public int randCycle;
        public bool staring;
		public int blSprt;
		public int bodySprt;
        public int hdSprt;
        // public float tail0;
        // public float tail1;
        // public float tail2;
        // public float tail3;
        public int lastChub; //OH WE ACTUALLY DON'T USE THIS ANYMORE...
        public float lastSquish;
        //public float tailBonus;
        public float[] tailBase;
		public bool verified;
    }
    public static BPgraph[] bpGraph;
    public static int totalPlayerNum = 100;

    public static void Patch()
    {
        bpGraph = new BPgraph[totalPlayerNum];
		
		On.PlayerGraphics.Reset += BP_Reset;
		On.PlayerGraphics.PlayerObjectLooker.HowInterestingIsThisObject += POL_HowInterestingIsThisObject;
        
		//WE WANT THIS TO RUN LAST, AFTER OTHER MODS, TO CAPTURE ANYTHING THAT SETS TAIL THICKNESS
		// using (new DetourContext(-333))
		On.PlayerGraphics.ctor += BPPlayerGraphics_ctor;
		On.PlayerGraphics.DrawSprites += BP_DrawSprites;
		On.PlayerGraphics.InitiateSprites += BP_InitiateSprites;
		
		// using (new DetourContext()) { } //NEEDED TO WORK AROUND A PRIORITIES BUG
    }


    public static void BPPlayerGraphics_ctor(On.PlayerGraphics.orig_ctor orig, PlayerGraphics self, PhysicalObject ow)
    {
        orig.Invoke(self, ow);
        int playerNum = patch_Player.GetPlayerNum(self.player); // self.player.playerState.playerNumber;

        bpGraph[playerNum] = new BPgraph
        {
            breathIn = false,
            randCycle = 1,
            staring = false,
            blSprt = 12,
            bodySprt = 0,
            hdSprt = 2 + self.tail.Length,
            lastChub = Math.Max(patch_Player.GetChubValue(self.player), 0),
            lastSquish = 0f,
            //tailBonus = GetTailBonus(self),
            tailBase = new float[self.tail.Length],
			verified = false, 
        };
		
		for (int i = 0; i < self.tail.Length; i++)
		{
			//bpGraph[playerNum].tailBase[i] = self.bodyParts[i].rad;
			bpGraph[playerNum].tailBase[i] = self.tail[i].rad;
		}
    }
	
	

    public static void BP_Reset(On.PlayerGraphics.orig_Reset orig, PlayerGraphics self)
    {
        orig.Invoke(self);
        //DON'T KNOW IF THIS COULD HAVE CONSEQUENCES FOR BACKGROUND SCENERY BUT THIS FIXES THE WEIRD BLUSH ISSUES SO I NEED IT
        if (BPOptions.blushEnabled.Value && !BellyPlus.VisualsOnly())
            self.BringSpritesToFront();
    }


    public static int GetHeadSprite(Player self)
    {
        return bpGraph[patch_Player.GetPlayerNum(self)].hdSprt;
    }


    public static float POL_HowInterestingIsThisObject(On.PlayerGraphics.PlayerObjectLooker.orig_HowInterestingIsThisObject orig, object self, PhysicalObject obj)
    {
        float interestValue = orig.Invoke((PlayerGraphics.PlayerObjectLooker)self, obj); //FIRST GRAB THE ORIGINAL
        if (obj is Creature && patch_Player.ObjIsStuckable(obj as Creature) && patch_Player.ObjIsStuck(obj as Creature))
        {
            interestValue += 0.5f;
        }
        return interestValue;
    }


    public static void BP_InitiateSprites(On.PlayerGraphics.orig_InitiateSprites orig, PlayerGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam)
    {
		//LET'S KEEP TRACK OF OUR BLUSH SPRITE INT. IT COULD CHANGE OR BE DIFFERENT BETWEEN SLUGCATS!
		int playerNum = patch_Player.GetPlayerNum(self.player);

        //Array.resize(array, newSize)
        //STORE THE TAIL THICKNESS INFO!
        
        

        orig.Invoke(self, sLeaser, rCam);


        //DOUBLE CHECK OUR TAIL SPRITES WERENT TINKERED WITH
        if (self.tail.Length != bpGraph[playerNum].tailBase.Length)
        {
            Debug.Log("OUR TAIL LENGTH WAS TINKERED WITH! RECALCULATE IT ");
            bpGraph[playerNum].tailBase = new float[self.tail.Length];
            //STORE THE TAIL THICKNESS INFO!
            for (int i = 0; i < self.tail.Length; i++)
            {
                bpGraph[playerNum].tailBase[i] = self.tail[i].rad;
            }

            for (int i = 0; i < self.bodyParts.Length; i++)
            {
                if (self.bodyParts[i] == self.head)
                    bpGraph[playerNum].hdSprt = i;
            }
            Debug.Log("NEW HEAD SPRITE " + bpGraph[playerNum].hdSprt);
        }


        //FlatLightBehindTerrain
        //"EdgeFade"
        //"LocalBloom"
        //"Steam"
        //"HazerHaze"
        //"FlatLightNoisy"
        //TRY THIS ONE this.fadeSprite.shader = game.rainWorld.Shaders["EdgeFade"];
        //self.AddToContainer(sLeaser, rCam, null);
        /*
        //WE'LL ADD IT TO OUR OWN CONTAINER SO IT ISN'T IN THE FOREGROUND
        FContainer newContatiner = rCam.ReturnFContainer("Midground");
        newContatiner.AddChild(sLeaser.sprites[bls]);
		
		//WE NEED TO FIND OUR BODY SPRITE
		if (BellyPlus.fancySlugsEnabled)
			bpGraph[playerNum].bodySprt = 5;

        //Debug.Log("INITIATE GRAPHICS! BLS " + bls + " -: " + sLeaser.sprites[bls].container);

        sLeaser.sprites[bls].MoveToFront(); //MOVE THE FACE OVER FRONT, PLS?
        //sLeaser.sprites[bls].MoveBehindOtherNode(sLeaser.sprites[9]);
        */

        if (BPOptions.blushEnabled.Value && !BellyPlus.VisualsOnly())
            PB_InitiateExtraFx(self, sLeaser, rCam, false);
    }



    public static void PB_InitiateExtraFx(PlayerGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, bool stealMark)
    {
        int playerNum = patch_Player.GetPlayerNum(self.player);
        //int bls = bpGraph[playerNum].blSprt;
        int bls = 12; 

        if (!stealMark)
        {
            Array.Resize<FSprite>(ref sLeaser.sprites, sLeaser.sprites.Length + 1);
            bls = sLeaser.sprites.Length - 1;
            sLeaser.sprites[bls] = new FSprite("Futile_White", true);
        }
        else
        {
            //sLeaser.sprites[bls].element = Futile.atlasManager.GetElementWithName("Futile_White");
        }
            

        bpGraph[playerNum].blSprt = bls;

        
        sLeaser.sprites[bls].shader = rCam.game.rainWorld.Shaders["FlatLightNoisy"];

        //WE'LL ADD IT TO OUR OWN CONTAINER SO IT ISN'T IN THE FOREGROUND
        FContainer newContatiner = rCam.ReturnFContainer("Midground");
        newContatiner.AddChild(sLeaser.sprites[bls]);

        //WE NEED TO FIND OUR BODY SPRITE
        //if (BellyPlus.fancySlugsEnabled)
        //    bpGraph[playerNum].bodySprt = 5;

        //Debug.Log("INITIATE GRAPHICS! BLS " + bls + " -: " + sLeaser.sprites[bls].container);

        //sLeaser.sprites[bls].MoveToFront(); //MOVE THE FACE OVER FRONT, PLS?
        sLeaser.sprites[bls].MoveBehindOtherNode(sLeaser.sprites[9]);
    }



    public static float GetTailBonus(PlayerGraphics self)
    {
        float bonusChubVal = patch_Player.GetOverstuffed(self.player);
        if (BellyPlus.VisualsOnly())
            bonusChubVal = Math.Min(bonusChubVal, 10);

        if (bonusChubVal > 25) //STUFFING PAST 10 WILL ONLY COUNT AS A THIRD OF IT'S NORMAL SIZE
            bonusChubVal = 25 + Mathf.Sqrt(bonusChubVal - 25); //AFTER 75 WE ADD THE SQRRT OF REMAINING
        bonusChubVal /= 10;
        return bonusChubVal;
    }


    //TAIL THICKNESS CHART BASED ON CHUB
    // static readonly float[] tailThickChart = { 1f, 1.1f, 1.25f, 1.4f, 1.5f };
    static readonly float[] tailThickChart = { 1f, 1.1f, 1.2f, 1.3f, 1.4f };

    public static void UpdateTailThickness(PlayerGraphics self) //, float tailThick)
    {
        int playerNum = patch_Player.GetPlayerNum(self.player); // self.player.playerState.playerNumber;

        //ACTUALLY, NO NO... WE COULD TOTALLY MAKE THIS A STATIC ADDITION INSTEAD OF MULT. WE WOULDN'T WANT TO MULT REALLY FAT TAILS
        //UM, WELL... EXCEPT THEN THE TAIL TIP WILL BE ALL FUNKY... RIGHT?
        //OKAY, HOW ABOUT ON INITIALIZE, WE SET A "PREVIOUS CHUB" VALUE EQUAL TO OUR CHUB (MAYBE FLOOR 0?)
        //AND ON UPDATING TAIL SIZE, WE FIRST USE OUR PREVIOUS CHUB VALUE TO UNDO OUR PREVIOUS TAIL THICKNESS BACK TO IT'S NORMAL SIZE
        //AND THEN IMMEDIATELY UPDATE IT TO IT'S NEW SIZE GIVEN OUR NEW CHUB VALUE
        //AND THEN UPDATE "PREV CHUB VALUE" FOR NEXT TIME. YE. NICE
        //OKAY NEVERMIND I AM REALLY BAD AT MATH. WE'LL JUST GET THE TAIL SIZE ON INITIALIZING AND USE THAT AS A BASE EACH TIME.

        //RECALCULATE HEAD SPRITE IN CASE OUR NUMBER OF BODYPARTS HAVE CHANGED FOR SOME REASON (BEECAT)
        for (int j = 0; j < self.bodyParts.Length; j++)
        {
            if (self.bodyParts[j] == self.head)
            {
                patch_PlayerGraphics.bpGraph[playerNum].hdSprt = j;
            }
        }

        //BEECAT BREAKS OUR TAIL!
        if (self.player.slugcatStats.name.value == "bee")
            return;


        //(0-4) DON'T LET THIS BE NEGATIVE. WE DON'T HAVE NEGATIVE ARRAY VALUES
        int newChubVal = Math.Max(patch_Player.GetChubValue(self.player), 0);
        float bonusChubVal = GetTailBonus(self);// Mathf.Min(GetTailBonus(self), 0.1f);

        // Debug.Log("TAIL CHONK!): " + tailThickChart[newChubVal] + " BONUS: " + bonusChubVal);
        for (int i = 0; i < self.tail.Length; i++)
        {
            //GET BACK TO OUR NON-FATTENED TAIL SIZE (NORMALRAD = CURRENTRAD / OLDSTR)
            //float normalTailSize = self.bodyParts[i].rad / tailThickChart[bpGraph[playerNum].lastChub];// - bpGraph[playerNum].tailBonus;
            //NOW ADJUST AS IF WE WERE MULTIPLYING BY THE BASE TAIL SIZE
            //self.bodyParts[i].rad = normalTailSize * tailThickChart[newChubVal] + bonusChubVal;
            //Debug.Log("TAIL THICC!: " + self.tail.Length + " i: " + i);
            //OKAY WE HAVE A BETTER WAY TO DO THAT NOW
            self.tail[i].rad = bpGraph[playerNum].tailBase[i] * tailThickChart[newChubVal] + bonusChubVal;
        }
        bpGraph[playerNum].lastChub = newChubVal; //AND STAY UP TO DATE
                                                  //bpGraph[playerNum].tailBonus = bonusChubVal;
    }


    public static void BP_DrawSprites(On.PlayerGraphics.orig_DrawSprites orig, PlayerGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
    {
        int playerNum = patch_Player.GetPlayerNum(self.player);


        //PRE UPDATE
        //REDUCE THE AMOUNT OF EXHAUSTION HEAVING WHEN LAYING ON BELLY
        //THIS DOESN'T DO JACK SQUAT :/
        /*
        if (!self.player.dead && self.player.room != null && (self.player.lungsExhausted || self.player.exhausted))
        {
            if (patch_Player.GetCreatureVector(self.player).x != 0)
            {
                //JUST REDUCE IT ALL BY HALF
                //self.head.vel.y -= 1f * (Mathf.Sin(self.player.swimCycle * 3.1415927f * 2f) * ((!self.player.lungsExhausted) ? 0.25f : 1f));
                //self.drawPositions[0, 0].y -= 1f * (Mathf.Sin(self.player.swimCycle * 3.1415927f * 2f) * ((!self.player.lungsExhausted) ? 0.75f : 2.5f));
                //self.head.Update();
                //self.head.ConnectToPoint(Vector2.Lerp(self.drawPositions[0, 0], self.drawPositions[1, 0], 0.2f) + vector5, (self.player.animation != Player.AnimationIndex.HangFromBeam) ? 3f : 0f, false, 0.2f, base.owner.bodyChunks[0].vel, 0.7f, 0.1f)
            }
        }
        */


        orig.Invoke(self, sLeaser, rCam, timeStacker, camPos);

        //HOPEFULLY TO HELP COMBAT ERROR LOG ISSUES!
        if (self.player.room == null)
            return;
		
		//TORSO SPRITE ARRAY POSITION CAN VARY
		int ct = bpGraph[playerNum].bodySprt; //CENTER TORSO 
		int hp = ct + 1;	//HIP

        float hipScale = 0;
        float torsoScale = 0;
		//float limbScale = 0;
		switch (patch_Player.GetChubFloatValue(self.player))
        {
            case 0f:
            default:
                torsoScale = 0f;
				hipScale = 0f;
                break;
            case 1f:
                torsoScale = 0f;
				hipScale = 2f;
                break;
            case 2f:
                torsoScale = 1f;
				hipScale = 5f;
				break;
            // case 2.5f:
                // torsoScale = 1.5f;
                // hipScale = 5.5f;
                // break;
            case 3f:
				torsoScale = 2f;
				hipScale = 7f;
				break;
			case 3.5f:
				torsoScale = 2.5f;
				hipScale = 8.5f;
				break;
			case 4f:
                torsoScale = 3f;
				hipScale = 10f;
				//limbScale = 10f;
                break;
        }
		
		//EXTRA CHUB IN ARENA MODE - OR IN EVERY MODE!
		//if (self.player.abstractCreature.world.game.IsArenaSession)
		//{
		int stuffing = patch_Player.GetOverstuffed(self.player);
        if (BellyPlus.VisualsOnly())
            stuffing = Math.Min(stuffing, 10);
        //Debug.Log("STUFFING!): " + stuffing + " CHUB" + patch_Player.GetChubValue(self.player));
        //torsoScale += (Mathf.Sqrt(stuffing)) / 3f; //OKAY, BUT MAYBE WE CAN IMPROVE THESE...
        //hipScale += (Mathf.Sqrt(stuffing)) / 2f;

        if (stuffing > 0f) //HOPEFULLY THIS WILL STOP IT
        {
            if (stuffing > 10) //STUFFING PAST 10 WILL ONLY COUNT AS A THIRD OF IT'S NORMAL SIZE
                stuffing = 10 + ((stuffing - 10) / 2);

            if (patch_Player.IsCramped(self.player))
            {
                hipScale += stuffing / 2f; //3
                torsoScale += Mathf.Min(stuffing, 15) / 6f;
            }
			else
			{
				hipScale += stuffing / 1.5f;
                torsoScale += Mathf.Min(stuffing, 15) / 3f;
			}
            //sLeaser.sprites[hp].scaleY += 0.05f * Mathf.Min(stuffing, 20);
            float heighBonus = stuffing;
            if (heighBonus > 15f) //STUFFING PAST 10 WILL ONLY COUNT AS A THIRD OF IT'S NORMAL SIZE
                heighBonus = 15f + ((heighBonus - 15f) / 3f);

            sLeaser.sprites[hp].scaleY += 0.05f * heighBonus;
        }
        //}

        //OVERSIZED CHARACTERS LOOK TOO WIDE. ADD SOME OF THAT WIDTH TO THEIR HEIGHT TO BALANCE OUT
        bool tubbyBuild = sLeaser.sprites[1].scaleX > 1.25f;  //TORSO SCALE ALWAYS RESETS EACH TICK SO WE CAN RELIABLY MEASURE IT
        if (tubbyBuild && stuffing < 10)
			sLeaser.sprites[hp].scaleY += 0.05f * (hipScale / 2f);

        if (patch_Player.PipeStatus(self.player))
            hipScale = Mathf.Min(hipScale, 20); //DON'T LET OUR FAT CLIP THROUGH WALLS IN CORRIDORS

        //BODY SQUASH AND STRETCH!
        if (patch_Player.IsStuck(self.player) && hipScale > 8)
        {
            //Debug.Log("STUFFING!): " + hipScale); // Mathf.Lerp(1f, 0f, patch_Player.GetStuckMod(self.player, 0.35f)));
            //hipScale *= Mathf.Lerp(1f, 0f, patch_Player.GetStuckMod(self.player, 0.35f));

            float stuckPerc = patch_Player.GetProgress(self.player) / Mathf.Max(((patch_Player.bellyStats[playerNum].tileTightnessMod) / 30) - 1, 0.1f);
            //stuckPerc = Mathf.Min(1f, stuckPerc);
            stuckPerc = 1f - Mathf.Max(0, stuckPerc);
			
			//OKAY THIS WOULD BE VERY SILLY THOUGH
			//if (patch_Player.PipeStatus(self.player))
			//	torsoScale = Mathf.Lerp(hipScale * 0.8f, torsoScale, stuckPerc);
			
            //Debug.Log("STUFFING!): " + stuckPerc);
            hipScale = Mathf.Lerp(7f, hipScale, stuckPerc);
        }
		
		
		sLeaser.sprites[ct].scaleX += 0.05f * torsoScale;
        sLeaser.sprites[hp].scaleX += 0.05f * hipScale;


        //MORE STRETCH AND SQUISHING
        float frc = patch_Player.GetSquishForce(self.player);
        if ( patch_Player.ObjBeingPushed(self.player) > 0)
		{
            //float boostPerc = Mathf.InverseLerp(10, 18, patch_Player.GetBoostStrain(self.player)) * (patch_Player.ObjBeingPushed(self.player) / 3f);
            //sLeaser.sprites[hp].scaleX *= Mathf.Lerp(1f, 1.35f, boostPerc);
            //sLeaser.sprites[hp].scaleY *= Mathf.Lerp(1f, 0.65f, boostPerc);
            if (frc > 5)
                frc += ((frc - 5) / 2f);
            float boostPerc = Mathf.InverseLerp(0, 8, frc);

            if (bpGraph[playerNum].lastSquish == 0) //SINGLE FRAME OF TWEEN SO IT'S LESS JARRING
                boostPerc *= 0.75f;

            sLeaser.sprites[hp].ScaleAroundPointRelative(new Vector2(0, 8), Mathf.Lerp(1f, 1.20f, boostPerc), Mathf.Lerp(1f, 0.80f, boostPerc));
            //self.tail[0].connectedPoint += patch_Player.ObjGetStuckVector(self.player) * 4f;
            // self.tail[0].pos += patch_Player.ObjGetStuckVector(self.player) * (boostPerc); // + (0.05f * hipScale)); //(0.05f * hipScale) *
			self.tail[0].pos += patch_Player.ObjGetStuckVector(self.player) * (3f + (0.05f * hipScale)) * (boostPerc);
        }
        bpGraph[playerNum].lastSquish = frc;



        //IF WE'RE DEAD, CUT THE REST. IT'S ALL EXPRESSION STUFF
        if (self.player.dead)
			return;

        bool exhaustionFxToggle = BPOptions.blushEnabled.Value && !(self.player.isNPC && self.player.isSlugpup) && !BellyPlus.VisualsOnly();
        float heatVal = 0;
        
        if (exhaustionFxToggle && rCam.cameraNumber == 0)
        {
            int bl = bpGraph[playerNum].blSprt;

            //SOMETIMES OUR SPRITE CONTAINER CAN JUST... GO MISSING I GUESS
            if (sLeaser.sprites[bl].container == null)
                PB_InitiateExtraFx(self, sLeaser, rCam, false);

            //sLeaser.sprites[bl].isVisible = true;
            //Debug.Log("BLSH CHECK " + sLeaser.sprites[bl].scale + " -VIS: " + sLeaser.sprites[bl].isVisible + " -CONT: " + sLeaser.sprites[bl].container + " -ALPHA: " + sLeaser.sprites[bl].alpha + " -SHAD: " + sLeaser.sprites[bl].shader + " -POS: " + sLeaser.sprites[bl].GetPosition() + " -WID: " + sLeaser.sprites[bl].width);
            //Debug.Log("BLSH CHECK " + sLeaser.sprites[bl].element + " -Anch: " + sLeaser.sprites[bl].GetAnchor() + " -TYPE: " + sLeaser.sprites[bl].GetType() + " -SCALEX: " + sLeaser.sprites[bl].scaleX + " -SORTZ: " + sLeaser.sprites[bl].sortZ + " -POS: " + sLeaser.sprites[bl].stage + " -WID: " + sLeaser.sprites[bl].height);
            sLeaser.sprites[bl].scale = 1.8f;
            sLeaser.sprites[bl].scaleY = 0.8f;
            sLeaser.sprites[bl].rotation = sLeaser.sprites[9].rotation;
            sLeaser.sprites[bl].color = Color.red;


            sLeaser.sprites[bl].x = sLeaser.sprites[9].x; // + Custom.DirVec(self.drawPositions[0, 0], self.objectLooker.mostInterestingLookPoint).x;
            sLeaser.sprites[bl].y = sLeaser.sprites[9].y -= 0.5f; // + Custom.DirVec(self.drawPositions[0, 0], self.objectLooker.mostInterestingLookPoint).y;
            //Debug.Log("-----RENDER LAYERS!: " + sLeaser.sprites[10]._renderLayer + "-" + sLeaser.sprites[3]._renderLayer);
            float breathNum = 0.5f + 0.5f * Mathf.Sin(Mathf.Lerp(self.lastBreath, self.breath, timeStacker) * 3.1415927f * 2f);
            float heatFloor = 400; //250
            float heatCeil = 1000; //750
            heatVal = Mathf.Min(Mathf.Max(patch_Player.GetHeat(self.player) - heatFloor, 0), heatCeil) / heatCeil;
            //Debug.Log("----BREATH!: " + breathNum + "  -  " + self.player.aerobicLevel + "  -  " + timeStacker + "-" + heatVal);

            if (patch_Player.GetBoostStrain(self.player) >= 10)
                heatVal *= 1.1f; //PUMP UP THE HEAD JUST A LITTLE BIT IF WE'RE BOOSTING HARD

            sLeaser.sprites[bl].alpha = heatVal * 0.4f;
            if (self.player.shortcutDelay > 1) // || patch_Player.IsGrabbedByPlayer(self.player))
                sLeaser.sprites[bl].alpha = 0f;

            //CHECK THIS FIRST BECAUSE WE MIGHT BE EXHAUSTTED
            if (self.player.isGourmand)
                self.player.ClassMechanicsGourmand();

            if (!self.player.lungsExhausted && !self.player.gourmandExhausted)
                self.player.aerobicLevel = Mathf.Max(self.player.aerobicLevel, heatVal) * 0.85f;

            //RELAXED EYES
            if (heatVal >= 0.7f && bpGraph[playerNum].randCycle < 3)
            {
                //sLeaser.sprites[9].element = Futile.atlasManager.GetElementWithName("Face" + ((!self.player.dead) ? "B" : "Dead"));
                self.player.Blink(5);
            }
            


            if (patch_Player.GetPant(self.player) && breathNum > 0.9f)
            {
                patch_Player.SetPant(self.player, false);
            }
            else if (!patch_Player.GetPant(self.player) && breathNum < 0.1f)
            {
                //breathIn = true;
                patch_Player.SetPant(self.player, true);
                float huffVol = heatVal * 0.45f * (self.player.lungsExhausted ? 0.6f : 1f);
                self.player.room.PlaySound(SoundID.Slugcat_Rocket_Jump, self.player.mainBodyChunk.pos, huffVol, 1.6f - (heatVal/2f) + Mathf.Lerp(-.2f, .2f, UnityEngine.Random.value));

                //ROLL THE DICE
                bpGraph[playerNum].randCycle = Mathf.FloorToInt(Mathf.Lerp(0f, 4f, UnityEngine.Random.value));


                //RUN A CHECK THAT HAS A CHANCE TO HUFF BASED ON OUR HEAT VALUE
                if (UnityEngine.Random.value < heatVal * Mathf.Max(1f - (self.player.aerobicLevel / 3f), 0f)) // (self.player.lungsExhausted ? 0.5f : 0f)
                {
                    Vector2 pos = self.head.pos + new Vector2(self.player.flipDirection * (10f + Mathf.Lerp(-5f, 5f, UnityEngine.Random.value)), -5f + Mathf.Lerp(-5f, 5f, UnityEngine.Random.value));
                    //self.player.room.PlaySound(SoundID.Lizard_Voice_Black_B, pos, 0.1f, 1f);
                    float lifetime = 25f;
                    float innerRad = 2f;
                    float width = 8f;
                    float length = 8f;
                    int spikes = 6;
                    ExplosionSpikes myPop = new ExplosionSpikes(self.player.room, pos, spikes, innerRad, lifetime, width, length, new Color(1f, 1f, 1f, 0.5f));
                    self.player.room.AddObject(myPop);
                }
            }
        }






        if (patch_Player.GetWideEyes(self.player) > 0) //|| (heatVal >= 1)
        {
            sLeaser.sprites[9].scaleY = 1.5f;
            sLeaser.sprites[9].y += 3f;
			self.blink = 0;
            
			if (exhaustionFxToggle && rCam.cameraNumber == 0)
            {
                int bl = bpGraph[playerNum].blSprt;
                sLeaser.sprites[bl].y += 3f;
                sLeaser.sprites[bl].scaleY += 0.4f;
                float alphaBoost = (Mathf.Min(patch_Player.GetWideEyes(self.player), 25f) / 25f) * 0.3f;
                sLeaser.sprites[bl].alpha += alphaBoost;
            }

            if (patch_Player.IsStuck(self.player))
                self.player.bodyChunks[0].vel.y = 8f;
        }
        else if (((patch_Player.IsStuckOrWedged(self.player) && patch_Player.IsPlayerSqueezing(self.player)) || patch_Player.IsPushingOther(self.player) || patch_Player.IsPullingOther(self.player)) && !self.player.lungsExhausted)
        {
            sLeaser.sprites[9].scaleY = 1f;
            //THIS MAKES THE > < FACE
            sLeaser.sprites[9].element = Futile.atlasManager.GetElementWithName("Face" + "Stunned");
            
            if (!patch_Player.IsPushingOther(self.player) && !patch_Player.IsPullingOther(self.player))
            {
                if (!patch_Player.IsVerticalStuck(self.player))
                {
                    //sLeaser.sprites[9].x += (5.0f * self.player.flipDirection);
                    sLeaser.sprites[9].y -= 1f; //patch_Player.GetYFlipDirection(self.player)
                    //if (blushToggle)
                        //sLeaser.sprites[10].x -= (1f * self.player.flipDirection);
					
					//IF WE DON'T SHRINK THE UPPER TORSO TO NORMAL SIZE HERE, IT LOOKS LIKE WE GOT WEIRD SHOULDERS.
					if (patch_Player.PipeStatus(self.player))
						sLeaser.sprites[ct].scaleX -= 0.05f * torsoScale;
                }

                if (self.player.input[0].IntVec != new IntVector2(0, 0))
                {
                    self.objectLooker.LookAtPoint(self.player.bodyChunks[0].pos + self.player.input[0].IntVec.ToVector2() * 50, 1f);
                    bpGraph[playerNum].staring = true; //SO WE CAN TURN IT OFF LATER
                }   
            }

            //Debug.Log("-----SQUISHING!: " + 1f + (patch_Player.GetStuckStrain(self.player) / 20f));
            //sLeaser.sprites[hp].scaleX *= 1f + (patch_Player.GetStuckStrain(self.player) / 200f);
            //sLeaser.sprites[hp].scaleY *= 1f - (patch_Player.GetStuckStrain(self.player) / 200f);
        }
        else
        {
            //IF WE'RE PANTING AND OUR EYES ARE CLOSED, MAKE EM EXTRA BIG!
            if (heatVal >= 0.7f && !self.player.lungsExhausted)
            {
                if (bpGraph[playerNum].randCycle < 3f)
                {
                    sLeaser.sprites[9].scaleY = 1.7f;
                    self.player.Blink(5);
                }
                else
                {
                    sLeaser.sprites[9].scaleY = 0.8f;
                }
            }   
            else
                sLeaser.sprites[9].scaleY = 1f;
        }


        //QUIT STARING OFF INTO SPACE!
        //if (self.player.bodyMode == Player.BodyModeIndex.CorridorClimb && !(patch_Player.ObjIsWedged(self.player) && self.player.input[0].IntVec != new IntVector2(0,0)))
        if (bpGraph[playerNum].staring && !patch_Player.IsStuckOrWedged(self.player) || self.player.input[0].IntVec == new IntVector2(0, 0))
        {
            if (self.objectLooker.lookAtPoint != null && UnityEngine.Random.value < 0.01f)
                self.objectLooker.lookAtPoint = null;
        }
		
		
		//FOR THOSE PESKY GRAPHICS MODS...
		bpGraph[playerNum].verified = true;

        
        bool debugBar = false;
        if (debugBar)
        {
            sLeaser.sprites[11].alpha = 1f;
            sLeaser.sprites[11].element = Futile.atlasManager.GetElementWithName("pixel");
            sLeaser.sprites[11].scale = 5f;
            //float barLen = patch_Player.GetExhaustionMod(self.player, 0f);

            float barLen = patch_Player.GetStuckPercent(self.player);
            sLeaser.sprites[11].scaleX = (8f * (1f - barLen) * 5f);

            //float barLen = patch_Player.GetProgress(self.player) / 1f;
            //sLeaser.sprites[11].scaleX = (8f * (barLen) * 5f);

            //float testAlpha = patch_Player.GetBoostStrain(self.player);
            //sLeaser.sprites[bl].alpha += testAlpha/8f;
            //sLeaser.sprites[bl].alpha += 0.5f;
        }
    }
	
	
	
	public static bool InspectGraphics(PlayerGraphics self)
    {
        int playerNum = patch_Player.GetPlayerNum(self.player);
		return bpGraph[playerNum].verified;
    }
}