﻿using RWCustom;


public class patch_SlugcatStats
{
    public static void Patch()
    {
        //On.SlugcatStats.SlugcatFoodMeter += SlugcatStats_SlugcatFoodMeter;
		//BUT CURRENTLY UNUSED, SINCE WE JUST EDITED MAXFOODINSTOMACH INSTEAD
    }
    /*
    public static IntVector2 SlugcatStats_SlugcatFoodMeter(On.SlugcatStats.orig_SlugcatFoodMeter orig, int slugcatNum)
    {
        //RETURNS THE DEFAULT, BUT INCREASE MAX FOOD BY 2
        int foodBonus = 0; // BellyPlus.bonusFood;
        return new IntVector2(orig.Invoke(slugcatNum).x + foodBonus, orig.Invoke(slugcatNum).y + 0);
    }
    */
}
