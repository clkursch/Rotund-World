using System;
using System.Collections.Generic;
using RWCustom;
using UnityEngine;


public class patch_DLL
{
	
	public static void Patch()
	{
		On.DaddyLongLegs.Update += DDL_Update;
		On.DaddyGraphics.DrawSprites += DaddyGraphics_DrawSprites;

		On.Centipede.ctor += Centipede_ctor;
		//On.CentipedeGraphics.DrawSprites += Centipede_DrawSprites;
        
		//On.PoleMimicGraphics.DrawSprites += BPPoleMimic_DrawSprites;
        On.PoleMimicGraphics.PoleMimicRopeGraphics.DrawSprite += BPPoleMimicRopeGraphics_DrawSprite;

        //On.PoleMimic.Rad += BP_Rad;
        //On.DropBugGraphics.ctor += DropBugGraphics_ctor;
    }

    private static void BPPoleMimicRopeGraphics_DrawSprite(On.PoleMimicGraphics.PoleMimicRopeGraphics.orig_DrawSprite orig, PoleMimicGraphics.PoleMimicRopeGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
    {
        if (GetChub(self.owner.pole) >= 0) //3)
        {
			float extraChonk = 3f;
			
			if ((sLeaser.sprites[0] as TriangleMesh).vertices.Length != self.segments.Length * 4)
            {
                self.InitiateSprites(sLeaser, rCam);

            }
            Vector2 vector = self.owner.pole.rootPos - self.owner.pole.stickOutDir * 30f;
            vector += Custom.DirVec(Vector2.Lerp(self.segments[1].lastPos, self.segments[1].pos, timeStacker), vector) * 1f;
            float num = 2f;
            for (int i = 0; i < self.segments.Length; i++)
            {
                float num2 = (float)i / (float)(self.segments.Length - 1);
                Vector2 vector2 = Vector2.Lerp(self.segments[i].lastPos, self.segments[i].pos, timeStacker);
                Vector2 normalized = (vector - vector2).normalized;
                Vector2 vector3 = Custom.PerpendicularVector(normalized) ;
                float num3 = Vector2.Distance(vector, vector2) / 3f * extraChonk;
                float num4 = self.owner.StemLookLikePole(num2, timeStacker);
                float num5 = Mathf.Lerp((i % 2 == 0) ? Mathf.Lerp(4f, 1.5f, num2) : Mathf.Lerp(1.4f, 0.75f, num2), 2f, Mathf.Pow(num4, 0.75f));
                (sLeaser.sprites[0] as TriangleMesh).MoveVertice(i * 4, vector - normalized * num3 - vector3 * Mathf.Lerp(num, num5, 0.5f) - camPos);
                (sLeaser.sprites[0] as TriangleMesh).MoveVertice(i * 4 + 1, vector - normalized * num3 + vector3 * Mathf.Lerp(num, num5, 0.5f) - camPos);
                (sLeaser.sprites[0] as TriangleMesh).MoveVertice(i * 4 + 2, vector2 + normalized * num3 - vector3 * num5 - camPos);
                (sLeaser.sprites[0] as TriangleMesh).MoveVertice(i * 4 + 3, vector2 + normalized * num3 + vector3 * num5 - camPos);
                float num6 = (1f + rCam.room.lightAngle.magnitude / 10f) * Mathf.Pow(num4, 1.8f);
                (sLeaser.sprites[1] as TriangleMesh).MoveVertice(i * 4, vector - normalized * num3 - vector3 * (Mathf.Lerp(num, num5, 0.5f) + num6) - camPos);
                (sLeaser.sprites[1] as TriangleMesh).MoveVertice(i * 4 + 1, vector - normalized * num3 + vector3 * (Mathf.Lerp(num, num5, 0.5f) + num6) - camPos);
                (sLeaser.sprites[1] as TriangleMesh).MoveVertice(i * 4 + 2, vector2 + normalized * num3 - vector3 * (num5 + num6) - camPos);
                (sLeaser.sprites[1] as TriangleMesh).MoveVertice(i * 4 + 3, vector2 + normalized * num3 + vector3 * (num5 + num6) - camPos);
                vector = vector2;
                num = num5;
            }
        }
        else
            orig.Invoke(self, sLeaser, rCam, timeStacker, camPos);
    }

    

    public static int GetChub(Creature self)
	{
		int critNum = self.abstractCreature.ID.RandomSeed;
		UnityEngine.Random.seed = critNum;
		int critChub = Mathf.FloorToInt(Mathf.Lerp(3, 9, UnityEngine.Random.value));
		if (critChub == 8)
			return 4;
		else
			return 0;
	}
	

	public static void DropBugGraphics_ctor(On.DropBugGraphics.orig_ctor orig, DropBugGraphics self, PhysicalObject ow)
    {
		orig.Invoke(self, ow);
		
		if (GetChub(self.bug) == 4 && !BellyPlus.VisualsOnly())
		{
			self.bodyThickness *= 1.5f;
		}
    }
	
	
	
	public static void Centipede_ctor(On.Centipede.orig_ctor orig, Centipede self, AbstractCreature abstractCreature, World world)
    {
		bool preMeatCheck = true; // self.CentiState.meatInitated;
		orig.Invoke(self, abstractCreature, world);
		
		if (GetChub(self) == 4 && !BellyPlus.VisualsOnly())
		{
			for (int i = 0; i < self.bodyChunks.Length; i++)
			{
				//PHAT
				self.bodyChunks[i].rad += Mathf.Lerp(1.5f, 2.5f, self.size) / 1.5f; //-2, 3.5
            }
			
			if (!preMeatCheck)
			{
				if (self.Centiwing) // || self.Small)
					abstractCreature.state.meatLeft += 1;
				else
					abstractCreature.state.meatLeft += 2;
			}
		}
    }
	
	
	
	
	
	public static void Centipede_DrawSprites(On.CentipedeGraphics.orig_DrawSprites orig, CentipedeGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
    {
		orig.Invoke(self, sLeaser, rCam, timeStacker, camPos);
		
		if (GetChub(self.centipede) == 4 && !BellyPlus.VisualsOnly())
		{
			for (int i = 0; i < self.owner.bodyChunks.Length; i++)
			{
				//PHAT
				// self.bodyChunks[i].rad += Mathf.Lerp(1.5f, 2.5f, self.size) / 1.5f; //-2/3.5
				sLeaser.sprites[self.SegmentSprite(i)].scaleY *= 1.5f;
            }
		}
    }
	
	

    private static void DaddyGraphics_DrawSprites(On.DaddyGraphics.orig_DrawSprites orig, DaddyGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
    {
		//Debug.Log("DO I EVEN RUN..." + self.daddy.digestingCounter);
		orig.Invoke(self, sLeaser, rCam, timeStacker, camPos);
		if (BellyPlus.VisualsOnly())
			return;
		
		//if (self.daddy.digestingCounter > 0)
		if (self.daddy.eatObjects.Count > 0)
        {
			//THIS WAS JUST FROM INITIATESPRITES MOVED INTO HERE
			for (int i = 0; i < self.daddy.bodyChunks.Length; i++)
			{
				sLeaser.sprites[self.BodySprite(i)].scale = (self.owner.bodyChunks[i].rad * 1.1f + 2f) / 8f;
				if (self.daddy.HDmode)
				{
					sLeaser.sprites[self.EyeSprite(i, 2)].scale = 0.0625f * self.owner.bodyChunks[i].rad * 2f;
				}
			}
		}
	}

    public static int GetRef(NeedleWorm self)
	{
		return self.abstractCreature.ID.RandomSeed;
	}
	

	public static void DDL_Update(On.DaddyLongLegs.orig_Update orig, DaddyLongLegs self, bool eu)
	{
		//if (self.digestingCounter > 15)
		if (self.eatObjects.Count > 0 && !BellyPlus.VisualsOnly())
		{
			for (int i = 0; i < self.bodyChunks.Length; i++)
			{
				self.bodyChunks[i].rad += 1/30f;
			}

            for (int l = 0; l < self.bodyChunkConnections.Length; l++)
            {
                self.bodyChunkConnections[l].distance += 1/90f;
            }
		}
		
		orig.Invoke(self, eu);

		//if (self.digestingCounter == 1 && self.graphicsModule != null)
		//	self.graphicsModule.Reset();
	}
	
	
	public static float BP_Rad(On.PoleMimic.orig_Rad orig, PoleMimic self, int index)
	{
		return (orig.Invoke(self, index) * 8f);
	}
	
}