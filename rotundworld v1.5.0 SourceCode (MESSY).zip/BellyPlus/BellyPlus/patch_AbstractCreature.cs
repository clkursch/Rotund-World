﻿using UnityEngine;

public class patch_AbstractCreature
{
    public static void Patch()
    {
        On.AbstractCreature.IsEnteringDen += BP_IsEnteringDen;
    }


	public static void BP_IsEnteringDen(On.AbstractCreature.orig_IsEnteringDen orig, AbstractCreature self, WorldCoordinate den)
	{
		try
		{
			//OH, I GUESS CICADAS DO THIS TOO!
			//YEEKS DO NOT, THEY CATCH FRUIT SO THIS WON'T RUN. HANDLED IN YEEKSTATE INSTEAD
			if (self.realizedCreature != null && (self.realizedCreature is Lizard || self.realizedCreature is Cicada || self.realizedCreature is Vulture) && self.abstractAI != null && self.abstractAI.HavePrey())
			{
				Creature mySelf = self.realizedCreature as Creature;
				BellyPlus.myFoodInStomach[BellyPlus.GetRef(mySelf)] += 2;

				//if (mySelf is Lizard)
				patch_Lizard.ObjUpdateBellySize(mySelf as Creature); //CICADAS CAN'T DO THIS... WAIT YES THEY CAN!!

				Debug.Log("CREATURE IN DEN - EATING A TASTY SNACK! " + BellyPlus.myFoodInStomach[patch_Lizard.GetRef(mySelf)]);
				// patch_Lizard.scoreMeal[GetRef(self)] = false;
			}
		}
		catch
		{
			Debug.Log("CATCH! BP CRASH ON TRYING TO ENTER DEN! ");
		}

		orig.Invoke(self, den);
	}
}