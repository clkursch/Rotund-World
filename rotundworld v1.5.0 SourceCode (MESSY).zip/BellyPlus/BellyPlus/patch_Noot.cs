using System;
using System.Collections.Generic;
using RWCustom;
using UnityEngine;



public class patch_Noot
{
	
	public static void Patch()
	{
        //On.Noot.ctor += BP_NootPatch;
        //On.NeedleWormGraphics.ctor += NootGraphics;
        On.NeedleWormGraphics.ctor += NootGraphics;
		On.NeedleWormGraphics.GraphSegmentRad += NootRad;
	}

	public static int GetRef(NeedleWorm self)
	{
		return self.abstractCreature.ID.RandomSeed;
	}
	
	//REPLICATE THE FORMULA THAT GUESSES OUR CHUB
	public static int GetChub(NeedleWorm self)
	{
		int critNum = self.abstractCreature.ID.RandomSeed;
		UnityEngine.Random.seed = critNum;
		int critChub = Mathf.FloorToInt(Mathf.Lerp(3, 9, UnityEngine.Random.value));
		if (critChub == 8)
			return 4;
		else
			return 0;
	}

	//public static void BP_Die(On.Noot.orig_Die orig, Noot self)
	//{
	//	BellyPlus.isStuck[GetRef(self)] = false;
	//	orig.Invoke(self);
	//}
	
	
	private static float NootRad(On.NeedleWormGraphics.orig_GraphSegmentRad orig, NeedleWormGraphics self, int i)
	{
		float result = orig.Invoke(self, i);
		
		if (i - self.snout.Length < self.worm.bodyChunks.Length && self.fatness > 1.25f)
		{
			float radMod = Mathf.Max(1f, self.fatness);
			//return self.worm.GetSegmentRadForCollision(i - self.snout.Length) * Mathf.Lerp(0.75f, 1.35f * capMod, self.fatness);
			result *= radMod;
		}
		
		return result;
	}
	
	

	public static void NootGraphics(On.NeedleWormGraphics.orig_ctor orig, NeedleWormGraphics self, PhysicalObject ow)
	{
		orig.Invoke(self, ow);
		
		
		int critNum = self.worm.abstractCreature.ID.RandomSeed;
		int seed = UnityEngine.Random.seed;
		UnityEngine.Random.seed = critNum;
		
		int critChub = Mathf.FloorToInt(Mathf.Lerp(3, 9, UnityEngine.Random.value));
		//critChub = 8;
		//if (critChub == 8)
  //      {
		//	self.fatness = 1.8f;
		//	self.worm.bodyChunks[0].mass *= 2f;
		//}
		if (critChub == 8)
        {
			self.fatness = 1.35f;
			self.worm.bodyChunks[0].mass *= 1.5f;
		}
			

		// this.fatness = Custom.ClampedRandomVariation(0.5f, 0.5f, 0.4f);
	}
	
	

}