﻿using RWCustom;
using UnityEngine;
using System;
using System.Collections.Generic;
using System.IO;

using System.Reflection;
using MonoMod.RuntimeDetour;
using Expedition;
using Menu;

using System.Text.RegularExpressions;
using Menu.Remix.MixedUI;

public class patch_Misc
{
    
	public delegate bool orig_Edible(SSOracleSwarmer self);
	
	public static void Patch()
    {
        On.WinState.CycleCompleted += BP_CycleCompleted;
        On.WinState.CreateAndAddTracker += BP_CreateAndAddTracker;
        On.WinState.PassageDisplayName += WinState_PassageDisplayName;

        On.FSprite.ctor_string_bool += FSprite_ctor_string_bool;
        On.FAtlasManager.GetElementWithName += FAtlasManager_GetElementWithName;
		
		On.Menu.MenuScene.BuildScene += BP_BuildScene;
        On.Menu.CustomEndGameScreen.GetDataFromSleepScreen += BP_GetDataFromSleepScreen;
        //On.Expedition.ChallengeTools.GenerateAchievementScores += BP_GenerateAchievementScores;

        On.Expedition.ExpeditionProgression.SetupBurdenGroups += ExpeditionProgression_SetupBurdenGroups;
        On.Expedition.ExpeditionProgression.BurdenName += ExpeditionProgression_BurdenName;
        On.Expedition.ExpeditionProgression.BurdenManualDescription += ExpeditionProgression_BurdenManualDescription;
        On.Expedition.ExpeditionProgression.BurdenScoreMultiplier += ExpeditionProgression_BurdenScoreMultiplier;
        On.Expedition.ExpeditionProgression.BurdenMenuColor += ExpeditionProgression_BurdenMenuColor;
        On.Menu.BurdenManualPage.ctor += BurdenManualPage_ctor;
        //On.Menu.UnlockDialog.ctor += UnlockDialog_ctor;
        On.Menu.UnlockDialog.UpdateBurdens += UnlockDialog_UpdateBurdens;
        On.Menu.UnlockDialog.Update += UnlockDialog_Update;

		
		On.FliesRoomAI.CreateFlyInHive += BP_CreateFlyInHive;
		
		//MAKE NEURONS EDITABLE
		BindingFlags propFlags = BindingFlags.Instance | BindingFlags.Public;
		BindingFlags myMethodFlags = BindingFlags.Static | BindingFlags.Public;

		Hook myCustomHook = new Hook(
			typeof(SSOracleSwarmer).GetProperty("Edible", propFlags).GetGetMethod(), // This gets the getter 
			typeof(patch_Misc).GetMethod("BP_Neuron_Editable", myMethodFlags) // This gets our hook method
		);
		
    }

    private static void UnlockDialog_Update(On.Menu.UnlockDialog.orig_Update orig, UnlockDialog self)
    {
		orig.Invoke(self);

		if (rotundBurden.Selected || rotundBurden.IsMouseOverMe)
		{
			// self.perkNameLabel.text = self.burdenNames[4];
			// self.perkDescLabel.text = self.burdenDescriptions[4];
			//FORGET THAT, THAT'S JUST ASKING FOR TROUBLE
			self.perkNameLabel.text = self.Translate("OBESE") + "+ 40%";
			self.perkDescLabel.text = self.Translate("Makes the player exceptionally prone to getting fat, making you struggle with your size even at the minimum food requirment.");
		}
	}

    public static BigSimpleButton rotundBurden;

	public static void UnlockDialog_UpdateBurdens(On.Menu.UnlockDialog.orig_UpdateBurdens orig, UnlockDialog self)
    {
		Vector2 vector1 = new Vector2(680f - (ModManager.MSC ? 325f : 248f), 310f);
		float num5 = 170f;
		if (true) //rotundBurden == null)
		{
			rotundBurden = new BigSimpleButton(self, self.pages[0], self.Translate(ExpeditionProgression.BurdenName("bur-rotund")), "bur-rotund", vector1 + new Vector2(num5 * 4f, -15f), new Vector2(150f, 50f), FLabelAlignment.Center, true);
			rotundBurden.buttonBehav.greyedOut = false; // !ExpeditionData.unlockables.Contains("bur-rotund");
			self.pages[0].subObjects.Add(rotundBurden);

		}


		//THIS MEANS ENABLED, NOT UNLOCKED
		if (ExpeditionGame.activeUnlocks.Contains("bur-rotund"))
		{
			Vector3 vector = Custom.RGB2HSL(ExpeditionProgression.BurdenMenuColor("bur-rotund"));
			rotundBurden.labelColor = new HSLColor(vector.x, vector.y, vector.z);
		}
		else
		{
			rotundBurden.labelColor = new HSLColor(1f, 0f, 0.35f);
		}

		orig.Invoke(self);
	}


    private static void BurdenManualPage_ctor(On.Menu.BurdenManualPage.orig_ctor orig, Menu.BurdenManualPage self, Menu.Menu menu, Menu.MenuObject owner)
    {
		orig.Invoke(self, menu, owner);
		float num = 0f;
		if (menu.CurrLang == InGameTranslator.LanguageID.German)
		{
			num = -15f;
		}
		MenuLabel menuLabel9 = new MenuLabel(menu, owner, ExpeditionProgression.BurdenName("bur-rotund") + " +" + ExpeditionProgression.BurdenScoreMultiplier("bur-rotund").ToString() + "%", new Vector2(35f + (menu as ExpeditionManualDialog).contentOffX, -30f + num), default(Vector2), true, null);
		menuLabel9.label.alignment = FLabelAlignment.Left;
		menuLabel9.label.color = ExpeditionProgression.BurdenMenuColor("bur-rotund");
		self.subObjects.Add(menuLabel9);
		string[] array5 = Regex.Split(ExpeditionProgression.BurdenManualDescription("bur-rotund").WrapText(false, 500f + (menu as ExpeditionManualDialog).wrapTextMargin, false), "\n");
		for (int m = 0; m < array5.Length; m++)
		{
			MenuLabel menuLabel10 = new MenuLabel(menu, owner, array5[m], new Vector2(35f + (menu as ExpeditionManualDialog).contentOffX, menuLabel9.pos.y - 15f - 15f * (float)m + num), default(Vector2), false, null);
			menuLabel10.label.SetAnchor(0f, 1f);
			menuLabel10.label.color = new Color(0.7f, 0.7f, 0.7f);
			self.subObjects.Add(menuLabel10);
		}
	}

    private static Color ExpeditionProgression_BurdenMenuColor(On.Expedition.ExpeditionProgression.orig_BurdenMenuColor orig, string key)
    {
		if (key == "bur-rotund")
		{
			return new Color(0.55f, 0.35f, 0f);
		}
		return orig.Invoke(key);
	}

    private static float ExpeditionProgression_BurdenScoreMultiplier(On.Expedition.ExpeditionProgression.orig_BurdenScoreMultiplier orig, string key)
    {
		if (key == "bur-rotund")
		{
			return 40f;
		}
		return orig.Invoke(key);
	}

    private static string ExpeditionProgression_BurdenManualDescription(On.Expedition.ExpeditionProgression.orig_BurdenManualDescription orig, string key)
    {
		if (key == "bur-rotund")
		{
			return ExpeditionProgression.IGT.Translate("Makes the player exceptionally prone to getting fat, making you struggle with your size even at the minimum food requirment.");
		}
		return orig.Invoke(key);
	}

    private static string ExpeditionProgression_BurdenName(On.Expedition.ExpeditionProgression.orig_BurdenName orig, string key)
    {
		if (key == "bur-rotund")
		{
			return ExpeditionProgression.IGT.Translate("OBESE");
		}
		return orig.Invoke(key);
	}

    private static void ExpeditionProgression_SetupBurdenGroups(On.Expedition.ExpeditionProgression.orig_SetupBurdenGroups orig)
    {
		//orig();
		orig.Invoke();
		//List<string> oldGroups = ExpeditionProgression.burdenGroups["expedition"];
		//List<string> value2 = new List<string>
		//{
		//	"bur-rotund"
		//};
		//ExpeditionProgression.burdenGroups.Add("expedition", value2);
		ExpeditionProgression.burdenGroups["expedition"].Add("bur-rotund");
	}

    public static bool BP_Neuron_Editable(orig_Edible orig, SSOracleSwarmer self)
	{
        if (self.grabbedBy.Count > 0 && self.grabbedBy[0].grabber is Player && (self.grabbedBy[0].grabber as Player).objectInStomach != null)
            return true;
		else
			return orig.Invoke(self); //OTHERWISE, JUST RUN AS NORMAL
	}
	
	
	
	// public static void BP_ChangeRoom(On.RoomCamera.ChangeRoom orig, RoomCamera self, Room newRoom, int cameraPosition)
	// {
		// orig.Invoke(self, newRoom, cameraPosition);
		// //REFRESH ANY SLUGCAT SQUEEZING SOUNDS
		// if (this.room != null)
		// {
			
		// }
	// }

    

    private static string WinState_PassageDisplayName(On.WinState.orig_PassageDisplayName orig, WinState.EndgameID ID)
	{
		if (ID == EnumExt_MyMod.Glutton)
			return "The Glutton";
		else
			return orig.Invoke(ID);
	}


	private static FAtlasElement FAtlasManager_GetElementWithName(On.FAtlasManager.orig_GetElementWithName orig, FAtlasManager self, string elementName)
    {
		if (elementName == "GluttonA")
			return orig.Invoke(self, "foodSymbol"); //HunterA //smallKarma3
		else if (elementName == "GluttonB")
			return orig.Invoke(self, "foodSymbol"); //HunterB
		else
			return orig.Invoke(self, elementName);
	}

    

    private static void FSprite_ctor_string_bool(On.FSprite.orig_ctor_string_bool orig, FSprite self, string elementName, bool quadType)
    {
		if (elementName == "GluttonA")
			orig.Invoke(self, "foodSymbol", quadType); //HunterA
		else if (elementName == "GluttonB")
			orig.Invoke(self, "foodSymbol", quadType); //HunterB
		else
			orig.Invoke(self, elementName, quadType);
	}



	public static void BP_BuildScene(On.Menu.MenuScene.orig_BuildScene orig, Menu.MenuScene self)
	{
		if (self.sceneID == EnumExt_MyScene.Endgame_Glutton)
		{
			//FIRST PART ALL OF THEM GET
			if (self is Menu.InteractiveMenuScene)
			{
				(self as Menu.InteractiveMenuScene).idleDepths = new List<float>();
			}
			Vector2 vector = new Vector2(0f, 0f);
			// vector..ctor(0f, 0f);

			//NOW THE CUSTOM PART
			self.sceneFolder = "Scenes" + Path.DirectorySeparatorChar.ToString() + "Endgame - Glutton";
			if (self.flatMode)
			{
				self.AddIllustration(new Menu.MenuIllustration(self.menu, self, self.sceneFolder, "Endgame - The Glutton - Flat", new Vector2(683f, 384f), false, true));
			}
			else
			{
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 6", new Vector2(71f, 49f), 2.2f, Menu.MenuDepthIllustration.MenuShader.Lighten));
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 5", new Vector2(71f, 49f), 1.5f, Menu.MenuDepthIllustration.MenuShader.Normal));
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 4", new Vector2(71f, 49f), 1.7f, Menu.MenuDepthIllustration.MenuShader.Normal));
				//self.depthIllustrations[self.depthIllustrations.Count - 1].setAlpha = new float?(0.5f);
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 3", new Vector2(71f, 49f), 1.7f, Menu.MenuDepthIllustration.MenuShader.LightEdges));
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 2", new Vector2(71f, 49f), 1.5f, Menu.MenuDepthIllustration.MenuShader.Normal));
				self.AddIllustration(new Menu.MenuDepthIllustration(self.menu, self, self.sceneFolder, "Glutton - 1", new Vector2(171f, 49f), 1.3f, Menu.MenuDepthIllustration.MenuShader.Normal)); //LightEdges
				//(self as Menu.InteractiveMenuScene).idleDepths.Add(2.2f);
				(self as Menu.InteractiveMenuScene).idleDepths.Add(2.2f);
				(self as Menu.InteractiveMenuScene).idleDepths.Add(1.7f);
				(self as Menu.InteractiveMenuScene).idleDepths.Add(1.7f);
				(self as Menu.InteractiveMenuScene).idleDepths.Add(1.5f);
				(self as Menu.InteractiveMenuScene).idleDepths.Add(1.3f);
			}
			self.AddIllustration(new Menu.MenuIllustration(self.menu, self, self.sceneFolder, "Glutton - Symbol", new Vector2(683f, 35f), true, false));
			Menu.MenuIllustration MenuIllustration4 = self.flatIllustrations[self.flatIllustrations.Count - 1];
			MenuIllustration4.pos.x = MenuIllustration4.pos.x - (0.01f + self.flatIllustrations[self.flatIllustrations.Count - 1].size.x / 2f);

		}
		else
			orig.Invoke(self);
	}


	private static void BP_GetDataFromSleepScreen(On.Menu.CustomEndGameScreen.orig_GetDataFromSleepScreen orig, Menu.CustomEndGameScreen self, WinState.EndgameID endGameID)
	{
		if (endGameID == EnumExt_MyMod.Glutton)
		{
			//GOTTA REPLICATE THE MENU SCREEN
			Menu.MenuScene.SceneID sceneID = Menu.MenuScene.SceneID.Empty;
			sceneID = EnumExt_MyScene.Endgame_Glutton;
			self.scene = new Menu.InteractiveMenuScene(self, self.pages[0], sceneID);
			self.pages[0].subObjects.Add(self.scene);
			self.pages[0].Container.AddChild(self.blackSprite);
			if (self.scene.flatIllustrations.Count > 0)
			{
				self.scene.flatIllustrations[0].RemoveSprites();
				self.scene.flatIllustrations[0].Container.AddChild(self.scene.flatIllustrations[0].sprite);
				self.glyphIllustration = self.scene.flatIllustrations[0];
				self.glyphGlowSprite = new FSprite("Futile_White", true);
				self.glyphGlowSprite.shader = self.manager.rainWorld.Shaders["FlatLight"];
				self.pages[0].Container.AddChild(self.glyphGlowSprite);
				self.localBloomSprite = new FSprite("Futile_White", true);
				self.localBloomSprite.shader = self.manager.rainWorld.Shaders["LocalBloom"];
				self.pages[0].Container.AddChild(self.localBloomSprite);
			}
			self.titleLabel = new Menu.MenuLabel(self, self.pages[0], "", new Vector2(583f, 5f), new Vector2(200f, 30f), false, null);
			self.pages[0].subObjects.Add(self.titleLabel);
			self.titleLabel.text = self.Translate(WinState.PassageDisplayName(endGameID));
		}
		else
			orig.Invoke(self, endGameID);
	}

	private static void BP_GenerateAchievementScores(On.Expedition.ChallengeTools.orig_GenerateAchievementScores orig)
	{
		orig.Invoke();
		Expedition.ChallengeTools.achievementScores.Add(EnumExt_MyMod.Glutton, 50);
	}


	

    public static void BP_CreateFlyInHive(On.FliesRoomAI.orig_CreateFlyInHive orig, FliesRoomAI self)
	{
		orig.Invoke(self);
		//JUST REPEAT THE PROCESS. DOUBLING IT
		if (self.room.hives.Length == 0 || BellyPlus.VisualsOnly())
		{
			return;
		}
		AbstractCreature abstractCreature = new AbstractCreature(self.room.game.world, StaticWorld.GetCreatureTemplate(CreatureTemplate.Type.Fly), null, self.RandomHiveNode(), self.room.game.GetNewID());
		self.room.abstractRoom.AddEntity(abstractCreature);
		abstractCreature.Realize();
		self.inHive.Add(abstractCreature.realizedCreature as Fly);
		
	}
	
	
	
	public static void BP_CycleCompleted(On.WinState.orig_CycleCompleted orig, WinState self, RainWorldGame game)
	{
		orig.Invoke(self, game);

		// ON CYCLE COMPLETED
		WinState.IntegerTracker integerTracker = self.GetTracker(WinState.EndgameID.Survivor, true) as WinState.IntegerTracker;
		WinState.IntegerTracker integerTracker5 = self.GetTracker(EnumExt_MyMod.Glutton, true) as WinState.IntegerTracker;
		if (integerTracker5 != null && !BellyPlus.VisualsOnly())// && integerTracker.GoalAlreadyFullfilled)
		{
			int gluttonProgress = BellyPlus.bonusFood;
			if (gluttonProgress > 4)
				gluttonProgress = 4 + ((gluttonProgress - 4) / 2);

			if (BPOptions.debugLogs.Value)
				Debug.Log("GLUTTON PROGRESS? " + gluttonProgress + "FILLED? " + integerTracker5.GoalAlreadyFullfilled);

			if (gluttonProgress > 0)
			{
				integerTracker5.SetProgress(integerTracker5.progress + gluttonProgress);
			}
			else if (integerTracker5 != null && !integerTracker5.GoalAlreadyFullfilled)
			{
				integerTracker5.SetProgress(integerTracker5.progress - Mathf.Max(2 - Mathf.CeilToInt(BPOptions.bpDifficulty.Value / 2), 1) );
			}
		}
	}
	
	
	public static WinState.EndgameTracker BP_CreateAndAddTracker(On.WinState.orig_CreateAndAddTracker orig, WinState.EndgameID ID, List<WinState.EndgameTracker> endgameTrackers)
	{
		// orig.Invoke(self, ID, endgameTrackers);
		
		WinState.EndgameTracker endgameTracker = null;
		
		if (ID != EnumExt_MyMod.Glutton) //WinState.EndgameID.Glutton)
			return orig.Invoke(ID, endgameTrackers); //JUST RUN THE ORIGINAL AND NOTHING ELSE BELOW IT
		
		if (ID == EnumExt_MyMod.Glutton)
		{
			endgameTracker = new WinState.IntegerTracker(ID, 0, 0, 0, 16);
			Debug.Log("GLUTTON TRACKER CREATED! ");
		}
		//AND THEN RUN THE ORIGINAL STUFF THAT WOULD OTHERWISE BE SKIPPED
		if (endgameTracker != null && endgameTrackers != null)
		{
			bool flag = false;
			for (int j = 0; j < endgameTrackers.Count; j++)
			{
				if (endgameTrackers[j].ID == ID)
				{
					flag = true;
					endgameTrackers[j] = endgameTracker;
					break;
				}
			}
			if (!flag)
			{
				endgameTrackers.Add(endgameTracker);
			}
		}
		return endgameTracker;
	}
	
	
	
	public static class EnumExt_MyMod
	{ // You can have multiple EnumExt_ classes in your assembly if you need multiple items with the same name for the different enum
		//public static SlugcatStats.Name YellowishWhite;
		//public static SlugcatStats.Name WhitishYellow;
		public static WinState.EndgameID Glutton = new WinState.EndgameID("Glutton", true);
	}
	
	
	public static class EnumExt_MyScene
	{
		public static Menu.MenuScene.SceneID Endgame_Glutton = new Menu.MenuScene.SceneID("Endgame_Glutton", true);
	}
}