﻿using UnityEngine;
using MonoMod.RuntimeDetour;
using MoreSlugcats;

public class patch_ShelterDoor
{
    public static void Patch()
    {
		// using (new DetourContext(333))
		On.ShelterDoor.DoorClosed += BP_DoorClosed;
		
		//SLIME_CUBED REPORTED THAT THIS IS NEEDED TO WORK AROUND A BUG WHERE MOD PRIORITIES FOR OTHER MODS AREN'T RESET UNLESS YOU RESET IT MANUALLY
		// using (new DetourContext()) { }
	}


	public static void BP_DoorClosed(On.ShelterDoor.orig_DoorClosed orig, ShelterDoor self)
	{
		if (BellyPlus.VisualsOnly())
		{
			orig.Invoke(self);
			return;
		}
		
		bool shelterTrapped = false;
		
		try
		{
			BellyPlus.ClearThins();
			Debug.Log("-DOOR CLOSED: " + self.room.game.Players.Count);

			//NOTE THIS ONLY APPLIES TO PLAYERS AND NOT SLUGPUPS
			for (int i = 0; i < self.room.game.Players.Count; i++)
			{
				Player player = (self.room.game.Players[i].realizedCreature as Player);
				if (player != null)
				{
					//Debug.Log("-STILL IN START?" + i + " -:" + (self.room.game.Players[i].realizedCreature as Player).stillInStartShelter);
					//Debug.Log("-SHELTER BONUS FRUIT! " + patch_Player.GetChubValue(player) + " OVERSTUFFED: " + patch_Player.GetOverstuffed(player) + " CURRENT FOOD:" + player.CurrentFood + " BONUS:" + BellyPlus.bonusFood + " " + BellyPlus.bonusHudPip);
					//Debug.Log("-STILL IN START?" + i + " -:" + (self.room.game.Players[i].realizedCreature as Player).stillInStartShelter);
					patch_Player.CheckBonusFood(player, true);

					//CAN WEEEE LOWER OUR FOOD INTAKE IF WE NEVER LEFT THE SHELTER?
					if (player.stillInStartShelter)
						shelterTrapped = true;
				}	
			}
		}
		catch
		{
			Debug.Log("CATCH! SHELTER DOOR INITIAL CHECK FAILURE");
		}


		try
		{
			//SPECIFICLLY FOR SLUGPUP NPCS
			for (int j = 0; j < self.room.abstractRoom.creatures.Count; j++)
			{
				if (ModManager.MSC 
					&& self.room.abstractRoom.creatures[j].realizedCreature != null
					&& self.room.abstractRoom.creatures[j].creatureTemplate.type == MoreSlugcatsEnums.CreatureTemplateType.SlugNPC
				)
				{
					Player player = self.room.abstractRoom.creatures[j].realizedCreature as Player;
					if (player != null && player.isNPC && player.isSlugpup)
					{
						int extraFoodCount = (player.CurrentFood - player.MaxFoodInStomach);
						Debug.Log("-PUP FOOD PIPS: " + player.CurrentFood + " MAX " + player.MaxFoodInStomach + " EXTRA " + extraFoodCount + " TO HIBERNATE " + player.slugcatStats.foodToHibernate);
						if (extraFoodCount >= 0)
						{
							//REMOVE ANY HALF PIPS
							//if ((extraFoodCount % 2) == 1)
							//	player.playerState.foodInStomach--;

							////REMOVE THE CORRECT AMNT OF PIPS (SHOULD BE 2 (OR 3 IF STARVED))
							//if (extraFoodCount >= player.slugcatStats.foodToHibernate && extraFoodCount > 1)
							//	player.playerState.foodInStomach -= (player.slugcatStats.foodToHibernate / 2);

							if ((extraFoodCount % 2) == 1)
							{
								extraFoodCount--;
								player.playerState.foodInStomach--;
							}
								

							////REPLACE OUR FAKE FOOD VALUE WITH WHAT THE ACTUAL NUMBER OF PIPS WOULD BE, R-RIGHT?
							//int newFoodVal = player.MaxFoodInStomach + (extraFoodCount / 2) - player.slugcatStats.foodToHibernate;
							//int leftoverBonusFood = Mathf.Max(0, newFoodVal - player.MaxFoodInStomach);
							//Debug.Log("-MORE PUP FOOD PIPS: NEWFOOD " + newFoodVal + " LEFTOVER " + leftoverBonusFood);
							//player.playerState.foodInStomach = newFoodVal + (leftoverBonusFood * 1) + player.slugcatStats.foodToHibernate;


							int hibernateCount = player.slugcatStats.foodToHibernate;
							for (int i = 0; i < (extraFoodCount / 2); i++)
							{
								if (hibernateCount > 0)
								{
									player.playerState.foodInStomach--;
									hibernateCount--;
								}
							}
						}
					}
				}
			}
		}
		catch
		{
			Debug.Log("CATCH! SHELTER DOOR PUP PIP FAILURE");
		}




		try
		{
			if (BellyPlus.bonusFood > 1 && ModManager.CoopAvailable)
			{
				//SHOULD WE ALSO PREVENT THEM FROM FARMING KARMA BY REDUCING IT BY 1?... HMM...
				// if ((self.room.world.game.session as StoryGameSession).saveState.deathPersistentSaveData.karma > 0)
					// (self.room.world.game.session as StoryGameSession).saveState.deathPersistentSaveData.karma--;
				
				//BUT REMEMBER WHO SHOULD BE WHAT SIZE IN THE MORNING
				int mostFat = 0;
				for (int i = 0; i < self.room.game.Players.Count; i++)
				{
					Player player = (self.room.game.Players[i].realizedCreature as Player);
					if (player != null)
					{
						int slugChub = patch_Player.ObjGetChubValue(player);

						if (shelterTrapped && BPOptions.hardMode.Value)
						{
							Debug.Log("-WE NEVER LEFT THE SHELTER! LOWER FOOD INTAKE");
							player.slugcatStats.foodToHibernate = 1;
						}


						if (slugChub >= mostFat)
						{
							if (slugChub > mostFat) //IF WE WERE EQUAL IN CHUB, MAKE IT IN ADDITION TO. OTHERWISE, MAKE US THE ONLY ONE
								BellyPlus.ThinAll();
							BellyPlus.theThinOnes[i] = false;
							mostFat = slugChub;
						}
					}
				}
			}
		}
		catch
		{
			Debug.Log("CATCH! SHELTER DOOR THIN CHECK FAILURE");
		}



		//FIND OUR LIZARDS?
		try
		{
			for (int j = 0; j < self.room.abstractRoom.creatures.Count; j++)
			{
				if (self.room.abstractRoom.creatures[j].realizedCreature != null 
					&& self.room.abstractRoom.creatures[j].realizedCreature is Lizard
				)
				{
					Lizard myLiz = self.room.abstractRoom.creatures[j].realizedCreature as Lizard;
					//MAKE SURE IT'S A LARGER VALUE FIRST
					if (BellyPlus.myFoodInStomach[BellyPlus.GetRef(myLiz)] > BellyPlus.lizardFood)
					{
						BellyPlus.lizardFood = BellyPlus.myFoodInStomach[BellyPlus.GetRef(myLiz)];
						Debug.Log("LZ! REMEMBERING MY LIZARDS FOOD VALUE!" + BellyPlus.lizardFood);
					}
				}
			}
			
			if (BellyPlus.lizardFood > 4)
				BellyPlus.lizardFood--;
		}
		catch
		{
			Debug.Log("CATCH! SHELTER DOOR LIZARD FATNESS FAILURE");
		}

		orig.Invoke(self);
	}
}