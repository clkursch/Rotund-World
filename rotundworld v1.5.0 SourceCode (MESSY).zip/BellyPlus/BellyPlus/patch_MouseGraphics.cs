﻿using RWCustom;
using UnityEngine;

public class patch_MouseGraphics
{
    public static void Patch()
    {
        On.MouseGraphics.DrawSprites += PG_DrawSprites;
        //On.MouseGraphics.InitiateSprites += PG_InitiateSprites;
    }

    static int bl = 20;
    static int hd = 15; //HEAD SPRITE

	/*
    public static void PG_InitiateSprites(On.MouseGraphics.orig_InitiateSprites orig, MouseGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam)
    {
        orig.Invoke(self, sLeaser, rCam);
        Array.Resize<FSprite>(ref sLeaser.sprites, sLeaser.sprites.Length + 1);
        sLeaser.sprites[bl] = new FSprite("Futile_White", true);
        //WE'LL ADD IT TO OUR OWN CONTAINER SO IT ISN'T IN THE FOREGROUND
        FContainer newContatiner = rCam.ReturnFContainer("Midground");
        newContatiner.AddChild(sLeaser.sprites[bl]);
        //sLeaser.sprites[9].MoveToFront(); //MOVE THE FACE OVER FRONT, PLS?

        //sLeaser.sprites[bl].MoveBehindOtherNode(sLeaser.sprites[15]); //PUT IT BEHIND THE FIRST EYE
        sLeaser.sprites[bl].MoveToFront();
        sLeaser.sprites[bl].alpha = 1f;
    }
	*/

    public static void PG_DrawSprites(On.MouseGraphics.orig_DrawSprites orig, MouseGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
    {
        orig.Invoke(self, sLeaser, rCam, timeStacker, camPos);

        if (self.mouse.room == null)
            return;

        int myMouse = patch_LanternMouse.GetRef(self.mouse);

        //DEAL WITH THIS IN HERE, SO IT DOESN'T RUN OFF SCREEN.
        self.mouse.bodyChunkConnections[0].distance = 12f + (4 + patch_Lizard.GetChubValue(self.mouse) / 4);

        //STRETCH OUT BASED ON STRAIN!
		float bodyStretch = Mathf.Min(BellyPlus.boostStrain[myMouse], 15f) * 0.7f;
		if (BellyPlus.beingPushed[myMouse] > 0 || (patch_LanternMouse.IsVerticalStuck(self.mouse) && patch_Lizard.GetYFlipDirection(self.mouse) > 0))
			bodyStretch *= 0.6f;
		self.mouse.bodyChunkConnections[0].distance += Mathf.Sqrt(bodyStretch);
		

        //RESET
        BellyPlus.pushingOther[myMouse] = false;
		
		//STOLEN FROM SLUGCAT HANDS
		LanternMouse myHelper = patch_LanternMouse.FindMouseInRange(self.mouse);
		if (myHelper != null && !BellyPlus.VisualsOnly())
			if (patch_Player.IsStuckOrWedged(myHelper) || patch_Player.ObjIsPushingOther(myHelper))
			{
                //WAIT... WHAT ABOUT THIS. OK THAT'S EASIER
                for (int l = 0; l < 2; l++)
                {
                    //self.limbs[0, l].pos = patch_Player.GetCreatureVector(self.mouse).ToVector2(); //BAD
                    self.limbs[0, l].pos += (myHelper.bodyChunks[1].pos - self.mouse.bodyChunks[0].pos) / 2;
                    //ISN'T THIS BACKWARDS? BUT OK
                    sLeaser.sprites[self.LimbSprite(0, l)].rotation = Custom.AimFromOneVectorToAnother( myHelper.bodyChunks[1].pos, self.mouse.bodyChunks[0].pos);
                }

                bool vertStuck = patch_LanternMouse.IsVerticalStuck(myHelper);
				if (!vertStuck && patch_LanternMouse.GetMouseAngle(self.mouse).x == patch_LanternMouse.GetMouseAngle(myHelper).x
					|| (vertStuck && patch_LanternMouse.GetMouseAngle(self.mouse).y == patch_LanternMouse.GetMouseAngle(myHelper).y))
				{
					//Debug.Log("-----MY PLAYER!?: " + findPlayerInRange(self.mouse).abstractCreature.ID.RandomSeed);
					patch_Player.ObjPushedOn(myHelper);
					patch_Lizard.PushedOther(self.mouse);
				}
			}
		
		
		//IF THEY'RE STUCK, MAYBE DON'T SHOW THEIR FORELEGS?
		if (patch_LanternMouse.IsStuck(self.mouse))
		{
			// sLeaser.sprites[this.LimbSprite(l, m)] //L:0 = FRONT LEGS. L:1 = HIND LEGS
			//sLeaser.sprites[self.LimbSprite(0, 0)].isVisible = false; 
			//sLeaser.sprites[self.LimbSprite(0, 1)].isVisible = false;
		}

        float hipScale = 0;
        float torsoScale = 0;
        switch (patch_Lizard.GetChubValue(self.mouse))
        {
            case 0:
                torsoScale = 0f;
                hipScale = 0f;
                break;
            case 1:
                torsoScale = 0f;
                hipScale = 2f;
                break;
            case 2:
                torsoScale = 1f;
                hipScale = 5f;
                break;
            case 3:
                torsoScale = 2f;
                hipScale = 8f;
                break;
            case 4:
                torsoScale = 3f;
                hipScale = 10f;
                break;
        }
        torsoScale = hipScale;

        //OK, WE MIGHT NEED TO CHEAT A BIT WITH THE MICE...
        float stuckBonus = 1;
        if (patch_LanternMouse.IsStuck(self.mouse))
        {
            stuckBonus = 2;
        }

        sLeaser.sprites[self.BodySprite(0)].scaleX = 1 + 0.02f * stuckBonus * hipScale;
        sLeaser.sprites[self.BodySprite(1)].scaleX = 1 + 0.05f * stuckBonus * hipScale;
        sLeaser.sprites[self.BodySprite(1)].scaleY = 1 + 0.02f  * hipScale;
        sLeaser.sprites[self.HeadSprite].scaleX = 1 + 0.01f * hipScale;
        //Debug.Log("----SQUEAK!: " + sLeaser.sprites[self.BodySprite(1)].scaleX);


        float heatVal = 0;
        float breathNum = 0;
		bool blushToggle = false;
        if (blushToggle)
        {

            sLeaser.sprites[bl].scale = 1.8f;
            sLeaser.sprites[bl].scaleY = 0.8f;
            sLeaser.sprites[bl].rotation = sLeaser.sprites[hd].rotation;
            sLeaser.sprites[bl].color = Color.red;

            sLeaser.sprites[bl].x = sLeaser.sprites[hd].x; // + Custom.DirVec(self.drawPositions[0, 0], self.objectLooker.mostInterestingLookPoint).x;
            sLeaser.sprites[bl].y = sLeaser.sprites[hd].y -= 0.5f; // + Custom.DirVec(self.drawPositions[0, 0], self.objectLooker.mostInterestingLookPoint).y;
            //Debug.Log("-----RENDER LAYERS!: " + sLeaser.sprites[10]._renderLayer + "-" + sLeaser.sprites[3]._renderLayer);
            //float breathNum = 0.5f + 0.5f * Mathf.Sin(Mathf.Lerp(self.lastBreath, self.breath, timeStacker) * 3.1415927f * 2f);
            // float breathNum = 0.5f + 0.5f * Mathf.Sin(self.breath * 3.1415927f * 2f);
            float breathRate = 20f; //WAS 2. WAY TOO FAST
            breathNum = 0.5f + 0.5f * Mathf.Sin((self.breath * timeStacker) * 3.1415927f * breathRate);
            float heatFloor = 250;
            float heatCeil = 750;
            heatVal = Mathf.Min(Mathf.Max(BellyPlus.myHeat[myMouse] - heatFloor, 0), heatCeil) / heatCeil;
            Debug.Log("MS!----BREATH!: " + breathNum + "  -  " + self.breath + "  -  " + timeStacker + "-" + heatVal);

            sLeaser.sprites[bl].alpha = heatVal * 0.7f;
        }
        


        if (BellyPlus.breathIn[myMouse] && breathNum > 0.9f)
        {
            //breathIn = false;
            // patch_LanternMouse.SetPant(self.mouse, false);
			BellyPlus.breathIn[myMouse] = false;
        }
        else if (!BellyPlus.breathIn[myMouse] && breathNum < 0.1f)
        {
            //breathIn = true;
            // patch_LanternMouse.SetPant(self.mouse, true);
			BellyPlus.breathIn[myMouse] = true;
            float huffVol = heatVal * 0.55f; //* (self.mouse.lungsExhausted ? 0.6f : 1f);
            self.mouse.room.PlaySound(SoundID.Slugcat_Rocket_Jump, self.mouse.mainBodyChunk.pos, huffVol, 1.6f - (heatVal / 2f) + Mathf.Lerp(-.2f, .2f, UnityEngine.Random.value));

            //ROLL THE DICE
            // bpGraph[playerNum].randCycle = Mathf.FloorToInt(Mathf.Lerp(0f, 4f, UnityEngine.Random.value));


            //RUN A CHECK THAT HAS A CHANCE TO HUFF BASED ON OUR HEAT VALUE
            if (UnityEngine.Random.value < heatVal) // * Mathf.Max(1f - (self.mouse.aerobicLevel / 3f), 0f)) // (self.mouse.lungsExhausted ? 0.5f : 0f)
            {
                Vector2 pos = self.bodyParts[4].pos + new Vector2(patch_LanternMouse.GetMouseAngle(self.mouse).x * (10f + Mathf.Lerp(-5f, 5f, UnityEngine.Random.value)), -5f + Mathf.Lerp(-5f, 5f, UnityEngine.Random.value));
                //self.mouse.room.PlaySound(SoundID.Lizard_Voice_White_C, pos, 0.1f, 1f);
                float lifetime = 25f;
                float innerRad = 2f;
                float width = 8f;
                float length = 8f;
                int spikes = 6;
                ExplosionSpikes myPop = new ExplosionSpikes(self.mouse.room, pos, spikes, innerRad, lifetime, width, length, new Color(1f, 1f, 1f, 0.5f));
                self.mouse.room.AddObject(myPop);
            }
        }
        
        if (BellyPlus.wideEyes[myMouse] > 0) //|| (heatVal >= 1)
        {
            if (blushToggle)
            {
                float alphaBoost = (Mathf.Min(BellyPlus.wideEyes[myMouse], 25f) / 25f) * 0.3f;
                sLeaser.sprites[bl].scaleY += 0.4f;
                sLeaser.sprites[bl].alpha += alphaBoost;
            }
            
			for (int num = 15; num < 19; num++) //ONLY SCALE A/B EYES, I THINK
			{
				sLeaser.sprites[num].scaleY = 1.5f; //THEY GET SCALED ON THEIR NORMAL RUN
			}
            self.mouse.bodyChunks[0].vel.y = 8f;
            self.ouchEyes = 0;
			//self.blink = 5;
        }
		else if (BellyPlus.lungsExhausted[myMouse])
		{
			self.blink = -15; //WE'RE EXHAUSTED! EYES CLOSED...
		}
		
        else if (((patch_LanternMouse.IsStuck(self.mouse)) || patch_Player.ObjIsPushingOther(self.mouse) || patch_Player.ObjIsPullingOther(self.mouse))) // && !self.mouse.lungsExhausted)
        {

            //THIS IS ALL WE NEED
            self.ouchEyes = 10;
            if (!patch_LanternMouse.IsVerticalStuck(self.mouse))
            {
                for (int num = 15; num < 19; num++)
                {
                    sLeaser.sprites[num].rotation += 180; //FLIP THE EYES!
                }
            }
        }
        else
        {
            //IF WE'RE PANTING AND OUR EYES ARE CLOSED, MAKE EM EXTRA BIG!
			
            if (heatVal >= 1)
            {
                
				//EH, THIS IS CUTER
				for (int num = 15; num < 19; num++) //ONLY SCALE A/B EYES, I THINK
				{
					sLeaser.sprites[num].scaleY = 0.7f; //THEY GET SCALED ON THEIR NORMAL RUN
                    Debug.Log("-----MOUSE EYES!: ");
                }
            }
        }


        
        bool debugBar = false;
        if (debugBar)
        {
            sLeaser.sprites[11].alpha = 1f;
            sLeaser.sprites[11].element = Futile.atlasManager.GetElementWithName("pixel");
            sLeaser.sprites[11].scale = 5f;
            //float barLen = patch_Lizard.GetExhaustionMod(self.mouse, 0f);
            float barLen = patch_Lizard.GetStuckPercent(self.mouse);
            sLeaser.sprites[11].scaleX = (8f * (1f - barLen) * 5f);
        }

    }

}