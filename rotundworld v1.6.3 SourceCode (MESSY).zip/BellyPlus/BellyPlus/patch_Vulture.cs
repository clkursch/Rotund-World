using System;
using System.Collections.Generic;
using RWCustom;
using UnityEngine;



public class patch_Vulture
{
	
	public static void Patch()
	{
		On.Vulture.ctor += BP_VulturePatch;
		// On.Vulture.Update += BPVulture_Update;
		//On.Vulture.VultureThruster.Update += BPThruster_Update;
	}


	public static Dictionary<int, Vulture> vultureBook = new Dictionary<int, Vulture>(0);

	private static void BP_VulturePatch(On.Vulture.orig_ctor orig, Vulture self, AbstractCreature abstractCreature, World world)
	{
		orig(self, abstractCreature, world);
		
		int critNum = self.abstractCreature.ID.RandomSeed;

		//MAKE SURE THERE ISN'T ALREADY A MOUSE WITH OUR NAME ON THIS!
		bool mouseExists = false;
        try
        {
			//ADD OURSELVES TO THE GUESTBOOK
			patch_Vulture.vultureBook.Add(critNum, self);
		}
		catch (ArgumentException)
        {
			mouseExists = true;
		}

		if (mouseExists)
        {
			Debug.Log("CREATURE ALREADY EXISTS! CANCELING: " + critNum);
			patch_Vulture.vultureBook[critNum] = self; //WELL HOLD ON! WE STALL NEED THE REFERENCE FROM THAT BOOK TO POINT TO US!
			UpdateBellySize(self);
			return;
		}
		
		BellyPlus.InitializeCreature(critNum);

		//NEW, LETS BASE OUR RANDOM VALUE ON OUR ABSTRACT CREATURE ID
		int seed = UnityEngine.Random.seed;
		UnityEngine.Random.seed = critNum;

		int critChub = Mathf.FloorToInt(Mathf.Lerp(3, 9, UnityEngine.Random.value));
		Debug.Log("CREATURE SPAWNED! CHUB SIZE: " + critChub);
		
		BellyPlus.myFoodInStomach[critNum] = critChub;
		
		UpdateBellySize(self);
	}
	
	public static int GetRef(Vulture self)
	{
		return self.abstractCreature.ID.RandomSeed;
	}

	
	


	public static void UpdateBellySize(Vulture self)
	{
		float baseWeight = self.IsMiros ? 1.8f : (1.2f * (self.IsKing ? 1.4f : 1f));
		float baseRad = 9.5f;
		float baseGrav = 0.9f;
		int currentFood = BellyPlus.myFoodInStomach[GetRef(self)];
		
		switch (Math.Min(currentFood, 8))
		{
			case 8:
				baseWeight *= 1.5f;
				baseRad *= 1.3f;
				baseGrav *= 1.3f;
				self.SetLocalGravity(0.9f);
				break;
			case 7:
				baseWeight *= 1.3f;
				baseRad *= 1.2f;
				baseGrav *= 1.2f;
				break;
			case 6:
				baseWeight *= 1.2f;
				baseRad *= 1.1f;
				baseGrav *= 1.05f;
				break;
			case 5:
				baseWeight *= 1.1f;
				baseRad *= 1.0f;
				break;
			case 4:
			default:
				baseWeight *= 1f;
				baseRad *= 1f;
				break;
		}
		
		self.SetLocalGravity(baseGrav);
		
		for (int i = 0; i < 4; i++)
		{
			self.bodyChunks[i].mass = baseWeight;
			self.bodyChunks[i].rad = baseRad;
		}
		
		patch_Lizard.UpdateChubValue(self);
	}









    public static void BPVulture_Update(On.Vulture.orig_Update orig, Vulture self, bool eu)
    {
		orig.Invoke(self, eu);

		float myChub = patch_Lizard.GetChubValue(self);
		if (myChub > 1)
        {
			if (myChub == 2f)
				myChub = 0.2f;
			else if (myChub == 3f)
				myChub = 0.3f;
			else
				myChub = 0.5f;

			for (int i = 0; i < 4; i++)
			{
				//JUST THE INVERSE OF THE NORMAL 
				//self.vulture.bodyChunks[i].vel += ((self.ThrustVector * (self.vulture.IsKing ? 1.2f : 0.8f) * self.Force) / 5f) * Math.Max(patch_Lizard.GetChubValue(self.vulture), 0);
				if (self.bodyChunks[i].vel.y > 4f)
					self.bodyChunks[i].vel.y -= myChub;
			}
		}
		
	}





    public static void BPThruster_Update(On.Vulture.VultureThruster.orig_Update orig, Vulture.VultureThruster self, bool eu)
	{
		//int critNum = self.abstractCreature.ID.RandomSeed;
		orig.Invoke(self, eu);
		
		if (self.Active)
		{
			for (int i = 0; i < 4; i++)
			{
				//JUST THE INVERSE OF THE NORMAL 
				//self.vulture.bodyChunks[i].vel += ((self.ThrustVector * (self.vulture.IsKing ? 1.2f : 0.8f) * self.Force) / 5f) * Math.Max(patch_Lizard.GetChubValue(self.vulture), 0);
				if (patch_Lizard.GetChubValue(self.vulture) > 1 && self.vulture.bodyChunks[i].vel.y > 1f)
					self.vulture.bodyChunks[i].vel /= patch_Lizard.GetChubValue(self.vulture);
			}
		}
	}
	
	

}