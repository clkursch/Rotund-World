﻿using UnityEngine;

public class patch_VultureGraphics
{
    public static void Patch()
    {
        On.VultureGraphics.InitiateSprites += VultureGraphics_InitiateSprites;
    }

	private static void VultureGraphics_InitiateSprites(On.VultureGraphics.orig_InitiateSprites orig, VultureGraphics self, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam)
	{
		orig.Invoke(self, sLeaser, rCam);
		
		//THEY ONLY EAT OFFSCREEN SO THIS SHOULD ALL BE FINE
		float bodyScale = 1f;
		if (patch_Lizard.GetChubValue(self.vulture) <= 0)
			bodyScale = 1f;
		else if (patch_Lizard.GetChubValue(self.vulture) == 1)
			bodyScale = 1.08f;
		else if (patch_Lizard.GetChubValue(self.vulture) == 2)
			bodyScale = 1.15f;
		else if (patch_Lizard.GetChubValue(self.vulture) == 3)
			bodyScale = 1.35f;
		else //(patch_Lizard.GetChubValue(self.vulture) == 4)
			bodyScale = 1.55f;
		
		//sLeaser.sprites[self.BodySprite].scale *= bodyScale;
		sLeaser.sprites[self.BodySprite].scaleX *= bodyScale;
	}
}