using BepInEx;
using UnityEngine;
using Menu.Remix.MixedUI;
using Menu.Remix.MixedUI.ValueTypes;


public class BPOptions : OptionInterface
{


    public BPOptions()
    {
        //BPOptions.hardMode = this.config.Bind<bool>("hardMode", true, new ConfigurableInfo("(This is just info I guess)", null, "", new object[] { "something idk" }));

        BPOptions.hardMode = this.config.Bind<bool>("hardMode", false);
        BPOptions.holdShelterDoor = this.config.Bind<bool>("holdShelterDoor", false);
        BPOptions.backFoodStorage = this.config.Bind<bool>("backFoodStorage", false);
        BPOptions.easilyWinded = this.config.Bind<bool>("easilyWinded", false);
        BPOptions.extraTime = this.config.Bind<bool>("extraTime", true);
        BPOptions.hudHints = this.config.Bind<bool>("hudHints", true);
        BPOptions.fatArmor = this.config.Bind<bool>("fatArmor", true);
        BPOptions.slugSlams = this.config.Bind<bool>("slugSlams", false);
        //BPOptions.dietNeedles = this.config.Bind<bool>("dietNeedles", false);
        BPOptions.detachNeedles = this.config.Bind<bool>("detachNeedles", false);
        BPOptions.visualsOnly = this.config.Bind<bool>("visualsOnly", false);

        BPOptions.debugTools = this.config.Bind<bool>("debugTools", false);
        BPOptions.debugLogs = this.config.Bind<bool>("debugLogs", false);
        BPOptions.blushEnabled = this.config.Bind<bool>("blushEnabled", false);
        BPOptions.bpDifficulty = this.config.Bind<float>("bpDifficulty", 0f, new ConfigAcceptableRange<float>(-5f, 5f));
        BPOptions.sfxVol = this.config.Bind<float>("sfxVol", 0.1f, new ConfigAcceptableRange<float>(0f, 0.4f));
        BPOptions.startThresh = this.config.Bind<int>("startThresh", 2, new ConfigAcceptableRange<int>(0, 4));
        BPOptions.jokeContent1 = this.config.Bind<bool>("jokeContent1", true);
    }



    public static Configurable<bool> blushEnabled;
    public static Configurable<bool> debugTools;
    public static Configurable<bool> holdShelterDoor;
    public static Configurable<bool> backFoodStorage;
    public static Configurable<bool> hardMode;
    public static Configurable<bool> easilyWinded;
    public static Configurable<bool> extraTime;
    public static Configurable<bool> hudHints;
    public static Configurable<bool> fatArmor;
    public static Configurable<bool> slugSlams;
    public static Configurable<bool> debugLogs;
    public static Configurable<float> bpDifficulty;
    public static Configurable<float> sfxVol;
    public static Configurable<int> startThresh;
    public static Configurable<bool> detachNeedles;
    public static Configurable<bool> visualsOnly;
    public static Configurable<bool> jokeContent1;


    public override void Update()
    {
        base.Update();

        //this.Tabs[0].items
        
        if (this.chkBoxVisOnly != null)
        {
            if (this.chkBoxVisOnly.GetValueBool() == true)
            {
                this.diffSlide.greyedOut = true;
                this.opLab1.Hidden = true;
                this.opLab2.Hidden = true;
                for (int i = 0; i < myBoxes.Length; i++)
                {
                    if (myBoxes[i] != null)
                        myBoxes[i].greyedOut = true;
                }
            }
            else
            {
                this.diffSlide.greyedOut = false;
                this.opLab1.Hidden = false;
                this.opLab2.Hidden = false;
                for (int i = 0; i < myBoxes.Length; i++)
                {
                    if (myBoxes[i] != null)
                        myBoxes[i].greyedOut = false;
                }
            }
        }
        
    }

    public static string BPTranslate(string t)
    {
        return OptionInterface.Translate(t); //this.manager.rainWorld.inGameTranslator.BPTranslate(t);
    }


    public OpFloatSlider diffSlide;
    public OpCheckBox chkBoxVisOnly;

    public OpCheckBox chkBoxslugSlams;
    public OpCheckBox chkBoxNeedles;

    public OpLabel opLab1;
    public OpLabel opLab2;

    public static OpCheckBox[] myBoxes;


    public override void Initialize()
    {
        base.Initialize();

        // OpTab opTab = new OpTab(this, "Options");
        this.Tabs = new OpTab[]
        {
            //opTab
			new OpTab(this, "Options"),
            new OpTab(this, "Misc"),
            new OpTab(this, "Info")
        };



        //Tabs = new OpTab[1];
        //Tabs[0] = new OpTab("Options");

        float lineCount = 530;

        Tabs[0].AddItems(new OpLabel(175f, lineCount + 50, BPTranslate("Hover over a setting to read more info about it")));


        //OpLabel opLabel = new OpLabel(new Vector2(100f, opRect.size.y - 25f), new Vector2(30f, 25f), ":(", FLabelAlignment.Left, true, null)
        //OpCheckBox opCheckBox = new OpCheckBox(this.config as Configurable<bool>, posX, posY)
        //this.numberPlayersSlider = new OpSliderTick(menu.oi.config.Bind<int>("_cosmetic", Custom.rainWorld.options.JollyPlayerCount, new ConfigAcceptableRange<int>(1, 4)), this.playerSelector[0].pos + new Vector2((float)num / 2f, 130f), (int)(this.playerSelector[3].pos - this.playerSelector[0].pos).x, false);
        // Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, "Makes squeezing through pipes even more difficult for fatter creatures") { description = "This is My Text" });

        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, "Makes squeezing through pipes even more difficult for fatter creatures") { description = "This is My Text" });
        // Tabs[0].AddItems(new OpSlider(BPOptions.bpDifficulty, new Vector2(50f, lineCount), 50, false));
        this.diffSlide = new OpFloatSlider(BPOptions.bpDifficulty, new Vector2(55f, lineCount - 0), 250, 0, false);
        Tabs[0].AddItems(this.diffSlide, new OpLabel(50f, lineCount - 15, BPTranslate("Pipe Size Difficulty")) { bumpBehav = this.diffSlide.bumpBehav, description = BPTranslate("Sets the average difficulty for squeezing through pipes, and the impact weight has on your agility") });

        Tabs[0].AddItems(this.opLab1 = new OpLabel(15f, lineCount + 5, BPTranslate("Wide")) { description = BPTranslate("Easy") });
        Tabs[0].AddItems(this.opLab2 = new OpLabel(320f, lineCount + 5, BPTranslate("Snug")) { description = BPTranslate("Hard") });

        //OpCheckBox chkBox5 = new OpCheckBox(BPOptions.hardMode, new Vector2(15f, lineCount));
        //Tabs[0].AddItems(chkBox5, new OpLabel(45f, lineCount, "Snug Pipes") { bumpBehav = chkBox5.bumpBehav });



        /*
		OpFloatSlider agilSlide = new OpFloatSlider(BPOptions.agilityDiff, new Vector2(55f, lineCount - 0), 250, 0, false);
		Tabs[0].AddItems(agilSlide, new OpLabel(50f, lineCount - 15, BPTranslate("Agility Penalty")) { bumpBehav = agilSlide.bumpBehav, description = BPTranslate("Your weight has a more noticeable impact on your ability to run, climb and jump") });

        Tabs[0].AddItems(new OpLabel(15f, lineCount + 5, BPTranslate("Easy")) );
        Tabs[0].AddItems(new OpLabel(320f, lineCount +5, BPTranslate("Hard")) );
		*/





        float indenting = 250f;

        lineCount -= 70;
        OpSlider threshSlide = new OpSlider(BPOptions.startThresh, new Vector2(55f, lineCount - 0), 150, false);
        string dscThresh = BPTranslate("Offset how much food you need to eat to get fat. Lower values will make you fat earlier.");
        // Tabs[0].AddItems(threshSlide, new OpLabel(50f, lineCount - 15, BPTranslate("Starting threshold")) { bumpBehav = threshSlide.bumpBehav, description = BPTranslate("Sets how close to full you must be before eating food will add weight. Lower values will make you fat earlier.") });
        Tabs[0].AddItems(threshSlide, new OpLabel(50f, lineCount - 15, BPTranslate("Starting threshold")) { bumpBehav = threshSlide.bumpBehav, description = dscThresh });
        Tabs[0].AddItems(new OpLabel(15f, lineCount + 5, BPTranslate("Early")) { description = BPTranslate("You will start getting fat before your belly is full.") });
        Tabs[0].AddItems(new OpLabel(220f, lineCount + 5, BPTranslate("Late")) { description = BPTranslate("You won't start getting fat until your belly is full") });
        threshSlide.description = dscThresh;


        string dscVisuals = BPTranslate("Removes all gameplay changes from the mod except visual ones");
        this.chkBoxVisOnly = new OpCheckBox(BPOptions.visualsOnly, new Vector2(15f + indenting + 50, lineCount));
        Tabs[0].AddItems(this.chkBoxVisOnly, new OpLabel(45f + indenting + 50, lineCount, BPTranslate("Visuals Only")) { bumpBehav = this.chkBoxVisOnly.bumpBehav, description = dscVisuals });
        this.chkBoxVisOnly.description = dscVisuals;
        //chkBoxVisOnly.Hidden = true;


        //Pipes are less snug and easier to wiggle through, even when very fat
        //Makes squeezing through pipes even more difficult for fatter creatures
        //Snug Pipes
        lineCount -= 60;
        string dsc5 = BPTranslate("Outgrowing pipes is more punishing on how long it takes to wiggle through");
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Outgrowing pipes is more punishing on how long it takes to wiggle through")) );
        OpCheckBox chkBox5 = new OpCheckBox(BPOptions.hardMode, new Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox5, new OpLabel(45f, lineCount, BPTranslate("Unforgiving Gap Sizes")) { bumpBehav = chkBox5.bumpBehav, description = dsc5 });
        chkBox5.description = dsc5;


        string dscArmor = BPTranslate("Increase resistance to bites based on how fat you are");
        OpCheckBox chkBoxArmor = new OpCheckBox(BPOptions.fatArmor, new Vector2(15f + indenting, lineCount));
        Tabs[0].AddItems(chkBoxArmor, new OpLabel(45f + indenting, lineCount, BPTranslate("Fat Armor")) { bumpBehav = chkBoxArmor.bumpBehav, description = dscArmor });
        chkBoxArmor.description = dscArmor;





        lineCount -= 40;
        string dsc6 = BPTranslate("Your weight has a more noticeable impact on your ability to run, climb and jump");
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Your weight has a more noticeable impact on your ability to run, climb and jump")) );
        OpCheckBox chkBox6 = new OpCheckBox(BPOptions.easilyWinded, new Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox6, new OpLabel(45f, lineCount, BPTranslate("Easily Winded")) { bumpBehav = chkBox6.bumpBehav, description = dsc6 });
        chkBox6.description = dsc6;

        if (ModManager.MSC)
        {
            string dscSlams = BPTranslate("All slugcats can do Gourmand's body slam, if fat enough");
            this.chkBoxslugSlams = new OpCheckBox(BPOptions.slugSlams, new Vector2(15f + indenting, lineCount));
            Tabs[0].AddItems(this.chkBoxslugSlams, new OpLabel(45f + indenting, lineCount, BPTranslate("Slug Slams")) { bumpBehav = this.chkBoxslugSlams.bumpBehav, description = dscSlams });
            this.chkBoxslugSlams.description = dscSlams;
        }
        else
        {
            BPOptions.slugSlams.Value = false;
        }





        lineCount -= 40;
        string dsc4 = BPTranslate("Double-tap the Grab button to store an edible item on your back like a spear");
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Double-tap the Grab button to store an edible item on your back like a spear")) );
        OpCheckBox chkBox4 = new OpCheckBox(BPOptions.backFoodStorage, new Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox4, new OpLabel(45f, lineCount, BPTranslate("Back Food Storage")) { bumpBehav = chkBox4.bumpBehav, description = dsc4 });
        chkBox4.description = dsc4;



        if (ModManager.MSC)
        {
            //string dscNeedles = BPTranslate("Spearmaster's needles will gain less food when your belly is full");
            //Diet Needles
            string dscNeedles = BPTranslate("When Spearmaster is full, switching hands (double tap grab) will detatch your needles");
            this.chkBoxNeedles = new OpCheckBox(BPOptions.detachNeedles, new Vector2(15f + indenting, lineCount));
            Tabs[0].AddItems(this.chkBoxNeedles, new OpLabel(45f + indenting, lineCount, BPTranslate("Detachable Needles")) { bumpBehav = this.chkBoxNeedles.bumpBehav, description = dscNeedles });
            this.chkBoxNeedles.description = dscNeedles;
        }


        lineCount -= 40;
        string dsc7 = BPTranslate("Slightly increase the cycle timer to account for the slowdowns");
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Slightly increase the cycle timer to account for the slowdowns")) );
        OpCheckBox chkBox7 = new OpCheckBox(BPOptions.extraTime, new Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBox7, new OpLabel(45f, lineCount, BPTranslate("Extra Cycle Time")) { bumpBehav = chkBox7.bumpBehav, description = dsc7 });
        chkBox7.description = dsc7;


        lineCount -= 40;
        string dscHints = BPTranslate("Occasionally show in-game hints related to controls and mechanics of the mod");
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, "Occasionally show in-game hints related to controls and mechanics of the mod") ); //{ description = "This is My Text" }
        OpCheckBox chkBoxHints = new OpCheckBox(BPOptions.hudHints, new Vector2(15f, lineCount));
        Tabs[0].AddItems(chkBoxHints, new OpLabel(45f, lineCount, BPTranslate("Hud Hints")) { bumpBehav = chkBoxHints.bumpBehav, description = dscHints });
        chkBoxHints.description = dscHints;

        myBoxes = new OpCheckBox[8];
        myBoxes[0] = chkBox5;
        myBoxes[1] = chkBoxArmor;
        myBoxes[2] = chkBox6;
        myBoxes[3] = chkBox4;
        myBoxes[4] = chkBox7;
        myBoxes[5] = chkBoxHints;
        if (ModManager.MSC)
        {
            myBoxes[6] = this.chkBoxslugSlams;
            myBoxes[7] = this.chkBoxNeedles;
        }



        //EHH, WE CAN DO WTHIS WITH SANDBOX MODE
        //OpCheckBox chkBox3 = new OpCheckBox(50f, 250f, "noRain", false);
        //      Tabs[0].AddItems(chkBox3,
        //          new OpLabel(50f, 280f, "No Rain") { bumpBehav = chkBox2.bumpBehav });

        //lineCount -= 65;
        //Tabs[0].AddItems(new OpLabel(50f, lineCount - 20f, "If enabled; shelter doors won't automatically close unless a player holds down to sleep") { description = "This is My Text" });
        //OpCheckBox chkBox3 = new OpCheckBox(BPOptions.holdShelterDoor, new Vector2(15f, lineCount));
        //Tabs[0].AddItems(chkBox3, new OpLabel(45f, lineCount, "Hold Shelter Doors") { bumpBehav = chkBox3.bumpBehav });







        //------------------ NEW TAB FOR OTHER STUFF



        lineCount = 550;
        Tabs[1].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Press Throw + Jump to add food pips. Press Crouch + Throw + Jump to subtract")));
        OpCheckBox chkBox2 = new OpCheckBox(BPOptions.debugTools, new Vector2(15f, lineCount));
        Tabs[1].AddItems(chkBox2, new OpLabel(45f, lineCount, BPTranslate("Debug Tools")) { bumpBehav = chkBox2.bumpBehav });

        lineCount -= 65;
        Tabs[1].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Development logs. For development things")));
        OpCheckBox chkLogs = new OpCheckBox(BPOptions.debugLogs, new Vector2(15f, lineCount));
        Tabs[1].AddItems(chkLogs, new OpLabel(45f, lineCount, BPTranslate("Debug Logs")) { bumpBehav = chkLogs.bumpBehav });


        lineCount -= 65;
        Tabs[1].AddItems(new OpLabel(50f, lineCount - 20f, BPTranslate("Adds a panting and red-faced visual effect when struggling for long periods of time")));
        OpCheckBox chkExample = new OpCheckBox(BPOptions.blushEnabled, new Vector2(15f, lineCount));
        Tabs[1].AddItems(chkExample, new OpLabel(45f, lineCount, BPTranslate("Exhaustion FX")) { bumpBehav = chkExample.bumpBehav });
        Tabs[1].AddItems(new OpLabel(50f, lineCount - 35f, BPTranslate("(can cause some visual glitches with held items)")));


        lineCount -= 95;
        OpFloatSlider sfxSlide = new OpFloatSlider(BPOptions.sfxVol, new Vector2(45f, lineCount - 25), 300, 1, false);
        Tabs[1].AddItems(sfxSlide, new OpLabel(45f, lineCount + 15, BPTranslate("Squeeze SFX Volume")) { bumpBehav = sfxSlide.bumpBehav, description = BPTranslate("Volume of the squeeze sound effect when slugcats are stuck") });
        Tabs[1].AddItems(new OpLabel(50f, lineCount - 40f, BPTranslate("(If the sfx is too soft or played without headphones)")));

        lineCount -= 80;
        Tabs[1].AddItems(new OpLabel(50f, lineCount, BPTranslate("Tip: The squeeze sfx pitch hints how close you are to popping free")));
        lineCount -= 20;
        Tabs[1].AddItems(new OpLabel(50f, lineCount, BPTranslate("Spending lots of stamina when you are close to freedom can help you pop through early!")));


        for (int j = 0; j < 2; j++)
        {
            int descLine = 155;
            Tabs[j].AddItems(new OpLabel(25f, descLine + 25f, "--- MOD FEATURES ---"));
            // Tabs[0].AddItems(new OpLabel(25f, descLine, "Press up against stuck creatures to push them. Grab them to pull"));
            // descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Press against stuck creatures to push them. Grab them and move backwards to pull")));
            descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Press Jump while pushing or pulling to strain harder and spend stamina")));
            descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Pivot dash, belly slide, or charge-jump into stuck creatures to ram them")));
            descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Spending stamina too quickly can make you exhausted and slow down progress")));
            descLine -= 30;
            //descLine -= 20;
            // Tabs[0].AddItems(new OpLabel(25f, 140f, "Certain fruits can be used to slicken up stuck creatures. Push against them with fruit in hand to apply"));
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Certain fruits can be used to slicken up stuck creatures. (blue fruit, slime mold, mushrooms, etc)")));
            descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("While stuck, tab the Grab button to smear fruit on yourself")));
            descLine -= 20;
            Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Push against stuck creatures with fruit in hand and press Jump to smear it on them")));
            descLine -= 25;
            if (ModManager.JollyCoop)
                Tabs[j].AddItems(new OpLabel(25f, descLine, BPTranslate("Hold Grab + Throw while holding food next to a co-op partner to feed them")));
        }





        //------------------ ANOTHER NEW TAB FOR OTHER STUFF

        lineCount = 550;

        Tabs[2].AddItems(new OpLabel(55f, lineCount, BPTranslate("If you run into any bugs or issues, let me know so I can fix them!")));

        lineCount -= 35;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Message me on discord: WillowWisp#3565 ")));
        lineCount -= 25;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Or ping @WillowWisp on the rain world Discord Server in the modding-support channel")));
        lineCount -= 25;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Or leave a comment on the mod workshop page in the Bug Reporting discussion!")));
        lineCount -= 25;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Or anywhere you want please I'm begging and sobbing please report your bugs")));

        lineCount -= 50;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Super bonus points if you include your error log files (if they generated)")));
        lineCount -= 25;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("located in: /Program Files (86)/Steam/steamapps/common/Rain World/exceptionLog.txt")));


        lineCount -= 50;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("Leave feedback on the mod page and rate the mod if you enjoy it!")));
        lineCount -= 25;
        Tabs[2].AddItems(new OpLabel(35f, lineCount, BPTranslate("If you post footage, send me a link! I'd love to see! :D")));


    }

}