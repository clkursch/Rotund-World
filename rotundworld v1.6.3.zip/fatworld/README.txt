NON-STEAM INSTALL INSTRUCTIONS
Drag the entire mod folder (the one containing modinfo.json) into this location:
\Rain World\RainWorld_Data\StreamingAssets\mods

The mod should then show up under the "Remix" menu for you to enable.

(For non steam versions)
MAKE SURE your version of the game is at least 1.9.05!! 
old versions may crash when hibernating in a shelter

Once enabled, you can click on the mod title to edit configuration settings.
-If you can see the mod config screen, you're all good to go! and the steps below can be skipped.

-- IF THE GAME SAYS ROTUND WORLD HAS NO REMIX USER INTERFACE CONFIGURATIONS --
Some outdated game files are preventing the mod from working, and need to be updated
1. Go to your \Steam\steamapps\common\Rain World  folder and DELETE the folder called "BepInEx"
2. Go to your steam library, open the properties for Rain World
3. Under the "Local Files" tab, click "Verify Integrity of game files"
4. That should fix the issue! You are all set to launch the game and play





Big thanks to all the open beta testers!
-Kanawha
-Blujay777
-LuckyTopHat
-Gnüsh
-Astral
-i dont have a name lol
-Camiu
-Laser
-(And more! lmn if I missed you)

More thanks to:
-W.James: For creating amazing art for the glutton passage
-Vigaro: for creating a custom modloader to bypass steam workshop bugs that prevented me from updating the mod
-Henpemaz & Slime_cubed: for being amazingly helpful with modding advice in the community

(If anyone wants the source code just ask, it's messy and hard to read :P)