﻿using RWCustom;
using UnityEngine;
using MoreSlugcats;

public class patch_SeedCob
{
    public static void Patch()
    {
		On.SeedCob.Update += BP_Update;
	}


	public static void BP_Update(On.SeedCob.orig_Update orig, SeedCob self, bool eu)
	{
		orig.Invoke(self, eu);
		
		//ALL WE'RE DOING HERE IS RE-RUNNING THE CHECK EXCLUDING THE PART THAT CHECKS IF YOUR BELLY IS FULL
		if (!self.AbstractCob.dead && self.open > 0.8f)
		{
			//for (int k = 0; k < self.room.game.Players.Count; k++)
			for (int k = 0; k < self.room.abstractRoom.creatures.Count; k++)
			{
				Creature realizedCreature = self.room.abstractRoom.creatures[k].realizedCreature;
				if (realizedCreature != null 
					&& realizedCreature is Player //OKAY THIS SHOULD DO THE TRICK. INCLUDE SLUGPUPS
					&& realizedCreature.room == self.room 
					&& (realizedCreature as Player).handOnExternalFoodSource == null 
					&& (realizedCreature as Player).eatExternalFoodSourceCounter < 1 
					&& (realizedCreature as Player).dontEatExternalFoodSourceCounter < 1
					&& (realizedCreature as Player).SlugCatClass != MoreSlugcatsEnums.SlugcatStatsName.Spear
					//&& (realizedCreature as Player).FoodInStomach < (realizedCreature as Player).MaxFoodInStomach 
					&& (realizedCreature as Player).dead == false //HOW DID I FORGET THIS?
					&& ((realizedCreature as Player).touchedNoInputCounter > 5 || (realizedCreature as Player).input[0].pckp))
				{
					int num5 = (realizedCreature as Player).FreeHand();
					if (num5 > -1)
					{
						Vector2 pos2 = realizedCreature.mainBodyChunk.pos;
						Vector2 vector3 = Custom.ClosestPointOnLineSegment(self.bodyChunks[0].pos, self.bodyChunks[1].pos, pos2);
						if (Custom.DistLess(pos2, vector3, 25f))
						{
							(realizedCreature as Player).handOnExternalFoodSource = new Vector2?(vector3 + Custom.DirVec(pos2, vector3) * 5f);
							(realizedCreature as Player).eatExternalFoodSourceCounter = 15;
							if (self.room.game.IsStorySession && (realizedCreature as Player).abstractCreature.creatureTemplate.type == CreatureTemplate.Type.Slugcat && !((realizedCreature as Player).abstractCreature.creatureTemplate.type == MoreSlugcatsEnums.CreatureTemplateType.SlugNPC) && self.room.game.GetStorySession.playerSessionRecords != null)
							{
								//self.room.game.GetStorySession.playerSessionRecords[(self.room.game.Players[k].state as PlayerState).playerNumber].AddEat(self);
								self.room.game.GetStorySession.playerSessionRecords[((realizedCreature as Player).abstractCreature.state as PlayerState).playerNumber].AddEat(self);
							}
							self.delayedPush = new Vector2?(Custom.DirVec(pos2, vector3) * 1.2f);
							self.pushDelay = 4;
							if ((realizedCreature as Player).graphicsModule != null)
							{
								((realizedCreature as Player).graphicsModule as PlayerGraphics).LookAtPoint(vector3, 100f);
							}
						}
					}
				}
			}
		}
	}
}