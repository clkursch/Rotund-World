﻿using System.Security.Cryptography;
using UnityEngine;

public class patch_AbstractCreature
{
    public static void Patch()
    {
        On.AbstractCreature.IsEnteringDen += BP_IsEnteringDen;
        On.ShortcutHandler.CreatureTakeFlight += BPShortcutHandler_CreatureTakeFlight;
    }

    public static void BPShortcutHandler_CreatureTakeFlight(On.ShortcutHandler.orig_CreatureTakeFlight orig, ShortcutHandler self, Creature creature, AbstractRoomNode.Type type, WorldCoordinate start, WorldCoordinate dest)
    {
        try
        {
            if (creature is Vulture)
            {
                if (creature.grasps[0] != null && creature.grasps[0].grabbed is Creature)  // && creature.Template.CreatureRelationship(creature.grasps[0].grabbed as Creature).type == CreatureTemplate.Relationship.Type.Eats)
                {
                    BellyPlus.myFoodInStomach[BellyPlus.GetRef(creature)] += 1;
                    patch_Lizard.ObjUpdateBellySize(creature);
                    Debug.Log("CREATURE DRAGGED PREY OFFSCREEN - EATING A TASTY SNACK! " + BellyPlus.myFoodInStomach[patch_Lizard.GetRef(creature)]);
                }

            }
        }
        catch
        {
            Debug.Log("CATCH! BP CRASH ON TRYING TO LEAVE TO OFFSCREEN DEN! ");
        }
        
		orig.Invoke(self, creature, type, start, dest);
    }

    public static void BP_IsEnteringDen(On.AbstractCreature.orig_IsEnteringDen orig, AbstractCreature self, WorldCoordinate den)
	{
		try
		{
			//OH, I GUESS CICADAS DO THIS TOO!
			//YEEKS DO NOT, THEY CATCH FRUIT SO THIS WON'T RUN. HANDLED IN YEEKSTATE INSTEAD
			if (self.realizedCreature != null && (self.realizedCreature is Lizard || self.realizedCreature is Cicada || self.realizedCreature is Vulture) && self.abstractAI != null && self.abstractAI.HavePrey())
			{
				Creature mySelf = self.realizedCreature as Creature;
				BellyPlus.myFoodInStomach[BellyPlus.GetRef(mySelf)] += 2;

				//if (mySelf is Lizard)
				patch_Lizard.ObjUpdateBellySize(mySelf as Creature); //CICADAS CAN'T DO THIS... WAIT YES THEY CAN!!

				Debug.Log("CREATURE IN DEN - EATING A TASTY SNACK! " + BellyPlus.myFoodInStomach[patch_Lizard.GetRef(mySelf)]);
				// patch_Lizard.scoreMeal[GetRef(self)] = false;
			}

            //MINI CREATURE UPDATES
            if (self.realizedCreature != null && self.realizedCreature is DropBug)
            {
                Creature mySelf = self.realizedCreature as Creature;
                int amnt = (BellyPlus.myFoodInStomach[BellyPlus.GetRef(mySelf)] >= 4) ? 1 : 2; //PAST TWO MEALS, SLOW DOWN THE CHONK
                //GAIN 2 IF HUNGRY. ONLY 1 IF FAT
                BellyPlus.myFoodInStomach[BellyPlus.GetRef(mySelf)] += amnt;
                patch_DLL.UpdateBellySize(mySelf as DropBug, amnt);
                Debug.Log("MINI CREATURE IN DEN - EATING A TASTY SNACK! " + BellyPlus.myFoodInStomach[patch_Lizard.GetRef(mySelf)]);
            }

        }
		catch
		{
			Debug.Log("CATCH! BP CRASH ON TRYING TO ENTER DEN! ");
		}

		orig.Invoke(self, den);
	}
}